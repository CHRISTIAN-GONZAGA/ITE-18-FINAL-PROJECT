<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Admin;
use App\Models\AdminRole;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create admin roles
        $roles = [
            [
                'role_name' => 'Super Admin',
                'role_level' => 3,
                'permissions' => json_encode([
                    'create_admin' => true,
                    'delete_admin' => true,
                    'view_actions' => true,
                    'manage_vehicles' => true,
                    'manage_owners' => true,
                    'manage_registrations' => true,
                    'manage_insurance' => true,
                    'manage_fines' => true,
                ])
            ],
            [
                'role_name' => 'Admin',
                'role_level' => 2,
                'permissions' => json_encode([
                    'create_admin' => false,
                    'delete_admin' => false,
                    'view_actions' => true,
                    'manage_vehicles' => true,
                    'manage_owners' => true,
                    'manage_registrations' => true,
                    'manage_insurance' => true,
                    'manage_fines' => true,
                ])
            ],
            [
                'role_name' => 'Operator',
                'role_level' => 1,
                'permissions' => json_encode([
                    'create_admin' => false,
                    'delete_admin' => false,
                    'view_actions' => false,
                    'manage_vehicles' => true,
                    'manage_owners' => true,
                    'manage_registrations' => true,
                    'manage_insurance' => true,
                    'manage_fines' => true,
                ])
            ]
        ];

        foreach ($roles as $roleData) {
            AdminRole::create($roleData);
        }

        // Create super admin
        Admin::create([
            'username' => 'superadmin',
            'email' => 'admin@systemite18.com',
            'password_hash' => Hash::make('admin123'),
            'role_id' => 1 // Super Admin role
        ]);

        // Create regular admin
        Admin::create([
            'username' => 'admin',
            'email' => 'operator@systemite18.com',
            'password_hash' => Hash::make('admin123'),
            'role_id' => 2 // Admin role
        ]);

        // Create operator
        Admin::create([
            'username' => 'operator',
            'email' => 'user@systemite18.com',
            'password_hash' => Hash::make('admin123'),
            'role_id' => 3 // Operator role
        ]);
    }
}
