<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\AdminRole;
use App\Models\Admin;
use App\Models\Address;
use App\Models\Owner;
use App\Models\Vehicle;
use App\Models\Registration;
use App\Models\Fine;
use App\Models\Insurance;
use App\Models\AdminAction;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Run admin seeder first
        $this->call(AdminSeeder::class);

        $recordCount = 50;

        Address::factory()->count($recordCount)->create();

        Owner::factory()->count($recordCount)->create();

        Vehicle::factory()->count($recordCount)->create();

        Registration::factory()->count($recordCount)->create();

        Fine::factory()->count($recordCount)->create();

        Insurance::factory()->count($recordCount)->create();

        AdminAction::factory()->count($recordCount)->create();
    }
}
