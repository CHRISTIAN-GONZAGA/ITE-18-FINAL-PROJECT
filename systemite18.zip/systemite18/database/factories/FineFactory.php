<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Fine;
use App\Models\Vehicle;

class FineFactory extends Factory
{
    protected $model = Fine::class;

    public function definition(): array
    {
        $issued = $this->faker->dateTimeBetween('-6 months', 'now');
        $isOverdue = $this->faker->boolean(60);
        $due = $isOverdue
            ? $this->faker->dateTimeBetween('-30 days', 'yesterday')
            : $this->faker->dateTimeBetween('tomorrow', '+60 days');

        return [
            'vehicle_id' => Vehicle::factory(),
            'serial_number' => strtoupper($this->faker->bothify('FINE-######')),
            'issued_date' => $issued->format('Y-m-d'),
            'due_date' => $due->format('Y-m-d'),
            'amount' => $this->faker->randomFloat(2, 100, 10000),
            'reason' => $this->faker->sentence(3),
            'created_by' => $this->faker->name(),
            'updated_by' => $this->faker->name(),
        ];
    }
}
