<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Vehicle;
use App\Models\Owner;

class VehicleFactory extends Factory
{
    protected $model = Vehicle::class;

    public function definition(): array
    {
        return [
            'owner_id' => Owner::factory(),
            'vin' => strtoupper($this->faker->bothify('??######??')),
            'make' => $this->faker->company(),
            'model' => $this->faker->word(),
            'color' => $this->faker->safeColorName(),
            'year' => $this->faker->year(),
            'vehicle_status' => $this->faker->randomElement(['Active', 'Inactive', 'Sold', 'Stolen']),
            'pin' => $this->faker->numerify(str_repeat('#', $this->faker->numberBetween(4, 10))), // Generate 4-10 digit PIN
        ];
    }

    public function forOwner($ownerId)
    {
        return $this->state(function () use ($ownerId) {
            return ['owner_id' => $ownerId];
        });
    }
}