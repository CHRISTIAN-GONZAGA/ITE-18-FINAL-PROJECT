<?php

namespace Database\Factories;

use App\Models\AdminAction;
use App\Models\Admin;
use Illuminate\Database\Eloquent\Factories\Factory;

class AdminActionFactory extends Factory
{
    protected $model = AdminAction::class;

    public function definition(): array
    {
        return [
            'admin_id'     => Admin::factory(),
            'action_type'  => $this->faker->randomElement([
                'CREATE',
                'UPDATE',
                'DELETE',
                'LOGIN',
                'LOGOUT',
            ]),
            'description'  => $this->faker->sentence(6),
        ];
    }
}
