<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Insurance;
use App\Models\Vehicle;

class InsuranceFactory extends Factory
{
    protected $model = Insurance::class;

    public function definition(): array
    {
        $start = $this->faker->dateTimeBetween('-6 months', 'now');
        $end = $this->faker->dateTimeBetween('now', '+90 days');
        return [
            'vehicle_id' => Vehicle::factory(),
            'serial_number' => strtoupper($this->faker->bothify('INS-######')),
            'provider' => $this->faker->company(),
            'policy_number' => $this->faker->bothify('POL-####-####'),
            'coverage' => $this->faker->sentence(),
            'start_date' => $start->format('Y-m-d'),
            'end_date' => $end->format('Y-m-d'),
            'created_by' => $this->faker->name(),
            'updated_by' => $this->faker->name(),
        ];
    }
}
