<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Registration;
use App\Models\Vehicle;

class RegistrationFactory extends Factory
{
    protected $model = Registration::class;

    public function definition(): array
    {
        $start = $this->faker->dateTimeBetween('-1 year', 'now');
        $end = $this->faker->dateTimeBetween('now', '+90 days');
        return [
            'vehicle_id' => Vehicle::factory(),
            'plate_number' => strtoupper($this->faker->bothify('???-####')),
            'registration_number' => strtoupper($this->faker->bothify('REG-####-####')),
            'registration_date' => $start->format('Y-m-d'),
            'expiration_date' => $end->format('Y-m-d'),
            'status' => $end >= new \DateTime('today') ? 'active' : 'expired',
        ];
    }

    // Optional helper to explicitly assign a vehicle
    public function forVehicle($vehicleId)
    {
        return $this->state(fn () => ['vehicle_id' => $vehicleId]);
    }
}
