<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Owner;
use App\Models\Address;

class OwnerFactory extends Factory
{
    protected $model = Owner::class;

    public function definition(): array
    {
        return [
            'FName' => $this->faker->firstName(),
            'LName' => $this->faker->lastName(),
            'address_id' => Address::factory(),
            'PhoneNumber' => $this->faker->phoneNumber(),
            'LicenseNumber' => $this->faker->numberBetween(100000, 999999),
            'created_by' => $this->faker->name(),
            'updated_by' => $this->faker->name(),
        ];
    }
}
