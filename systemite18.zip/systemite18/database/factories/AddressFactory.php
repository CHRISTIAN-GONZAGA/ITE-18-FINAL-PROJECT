<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Address;

class AddressFactory extends Factory
{
    protected $model = Address::class;

    public function definition(): array
    {
        return [
            'street' => $this->faker->streetName(),
            'city' => $this->faker->city(),
            'province' => $this->faker->state(),
            'postal_code' => $this->faker->postcode(),
            'created_at' => now()->toDateTimeString(),
            'created_by' => $this->faker->name(),
            'deleted_at' => null,
            'deleted_by' => null,
            'updated_at' => now()->toDateTimeString(),
            'updated_by' => $this->faker->name(),
        ];
    }
}
