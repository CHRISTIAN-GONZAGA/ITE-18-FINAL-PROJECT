<?php

namespace Database\Factories;

use App\Models\AdminRole;
use Illuminate\Database\Eloquent\Factories\Factory;

class AdminRoleFactory extends Factory
{
    protected $model = AdminRole::class;

    public function definition(): array
    {
        return [
            'role_name'   => $this->faker->jobTitle(),
            'role_level'  => $this->faker->numberBetween(1, 5),
            'permissions' => $this->faker->randomElement([
                'all',
                'manage_users,manage_data',
                'view_data',
            ]),
            'created_at'  => now(),
            'updated_at'  => now(),
        ];
    }
}
