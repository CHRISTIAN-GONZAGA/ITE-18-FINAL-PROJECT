<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admins', function (Blueprint $table) {
            $table->bigIncrements('admin_id');

            $table->unsignedBigInteger('role_id');
            $table->string('username', 100)->unique();
            $table->string('password_hash', 255);
            $table->string('email', 150)->unique();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('role_id')
                  ->references('admin_role_id')
                  ->on('admin_roles')
                  ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admins');
    }
};
