<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('registrations', function (Blueprint $table) {
            $table->bigIncrements('registration_id');
            $table->unsignedBigInteger('vehicle_id');
            $table->string('plate_number', 20);
            $table->date('registration_date');
            $table->date('expiration_date');
            $table->string('status', 50);

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('vehicle_id')->references('vehicle_id')->on('vehicles')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('registrations');
    }
};
