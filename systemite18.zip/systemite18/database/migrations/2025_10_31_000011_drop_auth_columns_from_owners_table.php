<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Drop auth-related columns if they exist
        if (Schema::hasColumn('owners', 'remember_token') || Schema::hasColumn('owners', 'email') || Schema::hasColumn('owners', 'email_verified_at') || Schema::hasColumn('owners', 'password')) {
            Schema::table('owners', function (Blueprint $table) {
                if (Schema::hasColumn('owners', 'remember_token')) {
                    $table->dropColumn('remember_token');
                }
                if (Schema::hasColumn('owners', 'password')) {
                    $table->dropColumn('password');
                }
                if (Schema::hasColumn('owners', 'email_verified_at')) {
                    $table->dropColumn('email_verified_at');
                }
                if (Schema::hasColumn('owners', 'email')) {
                    $table->dropColumn('email');
                }
            });
        }
    }

    public function down(): void
    {
        // No-op: we don't want to restore these columns
    }
};


