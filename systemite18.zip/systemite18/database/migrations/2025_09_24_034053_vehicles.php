<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->bigIncrements('vehicle_id');
            $table->unsignedBigInteger('owner_id');
            $table->string('vin', 50);
            $table->string('make', 50);
            $table->string('model', 50);
            $table->string('color', 50);
            $table->integer('year');
            $table->string('vehicle_status', 100);

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('owner_id')->references('owner_id')->on('owners')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
