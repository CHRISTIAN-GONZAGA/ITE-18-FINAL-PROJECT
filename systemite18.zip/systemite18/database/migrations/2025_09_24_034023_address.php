<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('address', function (Blueprint $table) {
            $table->bigIncrements('address_id');

            $table->string('street', 50);
            $table->string('city', 50);
            $table->string('province', 50);
            $table->string('postal_code', 50);

            $table->timestamps();
            $table->softDeletes();
            
            $table->string('created_by', 100)->nullable();
            $table->string('updated_by', 100)->nullable();
            $table->string('deleted_by', 100)->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('address');
    }
};
