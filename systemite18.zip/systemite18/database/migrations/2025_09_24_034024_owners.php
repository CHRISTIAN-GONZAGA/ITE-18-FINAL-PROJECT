<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('owners', function (Blueprint $table) {
            $table->bigIncrements('owner_id');

            $table->string('FName', 100);
            $table->string('LName', 100);
            $table->unsignedBigInteger('address_id');
            $table->string('PhoneNumber', 20);
            $table->bigInteger('LicenseNumber');

            $table->timestamps();
            $table->softDeletes();
            
            $table->string('created_by', 100)->nullable();
            $table->string('updated_by', 100)->nullable();
            $table->string('deleted_by', 100)->nullable();

            $table->foreign('address_id')->references('address_id')->on('address')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('owners');
    }
};
