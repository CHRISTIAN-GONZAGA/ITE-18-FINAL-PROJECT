<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('fines', function (Blueprint $table) {
            $table->bigIncrements('fine_id');

            $table->unsignedBigInteger('vehicle_id');
            $table->date('issued_date');
            $table->date('due_date');
            $table->decimal('amount', 10, 2);
            $table->string('reason', 100);

            $table->timestamps();
            $table->softDeletes();
            
            $table->string('created_by', 100)->nullable();
            $table->string('updated_by', 100)->nullable();
            $table->string('deleted_by', 100)->nullable();

            $table->foreign('vehicle_id')->references('vehicle_id')->on('vehicles')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('fines');
    }
};
