@extends('tramo.layout')

@section('content')
<section class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
	<div class="md:col-span-2 bg-white shadow border rounded-lg overflow-hidden">
		<img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=1200&auto=format&fit=crop" alt="hero" class="w-full h-60 object-cover">
		<div class="p-6">
			<h2 class="text-2xl font-semibold mb-2">Welcome to TraMo (Tracking Made Easy)</h2>
			<p class="text-sm text-gray-600">Stay in the driver’s seat with TraMo — search your vehicle and get real-time updates on registration, insurance, and violations.</p>
			<div class="mt-4 flex items-center gap-2">
				<a href="{{ route('tramo.vehicle') }}" class="px-4 py-2 bg-[#1b1b18] text-white rounded-sm">Search</a>
				<a href="{{ route('tramo.vehicle.create') }}" class="px-3 py-2 border rounded-sm text-sm">ADD (only for admin)</a>
			</div>
		</div>
	</div>
	<aside class="bg-white shadow border rounded-lg p-6">
		<label class="text-xs text-gray-500">Search</label>
		<form action="{{ route('tramo.vehicle') }}" method="get" class="mt-2 flex gap-2">
			<input name="q" class="flex-1 rounded-sm border px-3 py-2" placeholder="Search by PLATE NUMBER" />
			<button class="px-4 py-2 bg-[#1b1b18] text-white rounded-sm">Go</button>
		</form>
	</aside>
</section>

<section class="mt-12">
	<h3 class="text-xl font-semibold">Our Services</h3>
	<p class="text-xs text-gray-500">Fast and Accurate</p>
	<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
		<a href="{{ route('tramo.vehicle') }}" class="block bg-white border rounded-lg shadow overflow-hidden">
			<img class="h-44 w-full object-cover" src="https://images.unsplash.com/photo-1604079628040-94301bb21b91?q=80&w=1200&auto=format&fit=crop" alt="fines" />
			<div class="p-4">
				<h4 class="font-medium">Fees and Violations</h4>
				<p class="text-xs text-gray-600">Keep yourself up-to-date on existing concerns.</p>
			</div>
		</a>
		<a href="{{ route('tramo.vehicle') }}" class="block bg-white border rounded-lg shadow overflow-hidden">
			<img class="h-44 w-full object-cover" src="https://images.unsplash.com/photo-1556742031-c6961e8560b0?q=80&w=1200&auto=format&fit=crop" alt="insurance" />
			<div class="p-4">
				<h4 class="font-medium">Insurance</h4>
				<p class="text-xs text-gray-600">Know your coverage and policy.</p>
			</div>
		</a>
		<a href="{{ route('tramo.vehicle') }}" class="block bg-white border rounded-lg shadow overflow-hidden">
			<img class="h-44 w-full object-cover" src="https://images.unsplash.com/photo-1502877338535-766e1452684a?q=80&w=1200&auto=format&fit=crop" alt="registration" />
			<div class="p-4">
				<h4 class="font-medium">Registration</h4>
				<p class="text-xs text-gray-600">Keep your registration current.</p>
			</div>
		</a>
	</div>
</section>
@endsection


