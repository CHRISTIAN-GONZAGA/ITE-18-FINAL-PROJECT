@extends('tramo.layout')

@section('content')
<section class="max-w-3xl mx-auto mt-6">
	<h2 class="text-2xl font-semibold">Pick your ROLE!</h2>
	<p class="text-sm text-gray-600 mt-1">Welcome to TraMo! Please sign in to access your dashboard.</p>
	<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
		<a href="{{ route('tramo.login.customer') }}" class="block border rounded-lg bg-white p-6 shadow hover:shadow-md">
			<h3 class="font-medium">Log in<br>Customer</h3>
			<p class="text-xs text-gray-500 mt-2">Experience and enjoy</p>
		</a>
		<a href="{{ route('tramo.login.admin') }}" class="block border rounded-lg bg-white p-6 shadow hover:shadow-md">
			<h3 class="font-medium">Log in<br>Admin</h3>
			<p class="text-xs text-gray-500 mt-2">Manage and expand</p>
		</a>
	</div>
</section>
@endsection


