@extends('tramo.layout')

@section('content')
<div class="max-w-md mx-auto mt-10 bg-white border rounded-lg shadow p-6">
	<h2 class="text-xl font-semibold text-center">WELCOME, ADMIN!</h2>
	<form class="mt-6 space-y-4">
		<div>
			<label class="text-xs text-gray-600">USERNAME</label>
			<input class="w-full border rounded-sm px-3 py-2" placeholder="Input" />
		</div>
		<div>
			<label class="text-xs text-gray-600">PASSWORD</label>
			<input type="password" class="w-full border rounded-sm px-3 py-2" placeholder="Input" />
		</div>
		<button type="button" class="w-full bg-[#1b1b18] text-white py-2 rounded-sm">SUBMIT</button>
	</form>
</div>
@endsection


