@extends('tramo.layout')

@section('content')
<a href="{{ url()->previous() }}" class="text-sm underline">Back</a>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-10 mt-4">
	<section>
		<h3 class="text-2xl font-semibold mb-4">Vehicle Details</h3>
		<div class="space-y-3">
			<input class="w-full border rounded-sm px-3 py-2" placeholder="VIN" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="MAKE" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="MODEL" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="YEAR" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="COLOR" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="PLATE NUMBER" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="REGISTRATION NUMBER" />
			<div class="grid grid-cols-2 gap-3">
				<input class="border rounded-sm px-3 py-2" placeholder="START DATE" />
				<input class="border rounded-sm px-3 py-2" placeholder="END DATE" />
			</div>
		</div>

		<h3 class="text-xl font-semibold mt-8 mb-3">Insurance Details</h3>
		<div class="space-y-3">
			<input class="w-full border rounded-sm px-3 py-2" placeholder="SERIAL NUMBER" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="PROVIDER" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="POLICY NUMBER" />
			<div class="grid grid-cols-2 gap-3">
				<input class="border rounded-sm px-3 py-2" placeholder="START DATE" />
				<input class="border rounded-sm px-3 py-2" placeholder="END DATE" />
			</div>
		</div>
	</section>

	<section>
		<h3 class="text-2xl font-semibold mb-4">Owner details</h3>
		<div class="grid grid-cols-2 gap-3">
			<input class="border rounded-sm px-3 py-2" placeholder="First Name" />
			<input class="border rounded-sm px-3 py-2" placeholder="Last Name" />
			<input class="col-span-2 border rounded-sm px-3 py-2" placeholder="Address Street" />
			<input class="border rounded-sm px-3 py-2" placeholder="City" />
			<input class="border rounded-sm px-3 py-2" placeholder="Province" />
			<input class="border rounded-sm px-3 py-2" placeholder="Postal Code" />
			<input class="col-span-2 border rounded-sm px-3 py-2" placeholder="Phone Number" />
			<input class="col-span-2 border rounded-sm px-3 py-2" placeholder="License Code" />
		</div>

		<h3 class="text-xl font-semibold mt-8 mb-3">Violations</h3>
		<div class="space-y-3">
			<div class="grid grid-cols-3 gap-3 items-center">
				<label class="text-sm text-gray-600">Quantity</label>
				<input class="border rounded-sm px-3 py-2" value="1" />
			</div>
			<input class="w-full border rounded-sm px-3 py-2" placeholder="SERIAL NUMBER" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="REASON" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="AMOUNT" />
			<input class="w-full border rounded-sm px-3 py-2" placeholder="DATE ISSUED" />
		</div>
		<button class="mt-6 w-full bg-[#1b1b18] text-white py-2 rounded-sm">SUBMIT</button>
	</section>
</div>
@endsection


