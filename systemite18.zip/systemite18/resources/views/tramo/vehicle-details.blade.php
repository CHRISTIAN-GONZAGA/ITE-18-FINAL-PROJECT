@extends('tramo.layout')

@section('content')
<nav class="text-xs text-gray-500 mb-4"><a href="{{ route('tramo.home') }}" class="underline">Home</a> / Vehicle Details</nav>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
	<div class="lg:col-span-2 bg-white border rounded-lg shadow p-6">
		<div class="h-48 bg-gray-100 rounded mb-6"></div>
		<h2 class="text-2xl font-semibold">Model and Make</h2>
		<p class="text-sm text-gray-500 mt-1">Owner</p>
		<div class="mt-4 grid grid-cols-3 gap-3">
			<button class="px-3 py-2 rounded-sm border">Violations</button>
			<button class="px-3 py-2 rounded-sm border">Insurance</button>
			<button class="px-3 py-2 rounded-sm border">Registration</button>
		</div>

		<div class="mt-6 grid grid-cols-2 gap-6">
			<div>
				<label class="text-xs text-gray-500">Quantity</label>
				<div class="text-2xl font-semibold">1</div>
			</div>
			<div>
				<label class="text-xs text-gray-500">Provider Name</label>
				<div class="text-base">—</div>
			</div>
		</div>

		<div class="mt-6 grid grid-cols-2 gap-6 text-sm">
			<div>
				<p class="text-gray-500">Registration Number:</p>
				<p class="text-gray-900">DATA</p>
			</div>
			<div>
				<p class="text-gray-500">Registration Status:</p>
				<p class="text-gray-900">ACTIVE/EXPIRED</p>
			</div>
			<div>
				<p class="text-gray-500">Plate Number:</p>
				<p class="text-gray-900">DATA</p>
			</div>
		</div>
	</div>

	<div class="space-y-6">
		<section class="bg-white border rounded-lg shadow p-6">
			<h3 class="font-semibold text-center">Insurance Details</h3>
			<div class="mt-4 grid grid-cols-2 gap-3 text-sm">
				<label class="text-gray-500">Policy Number</label><div>DATA</div>
				<label class="text-gray-500">Duration</label><div>DATA</div>
				<label class="text-gray-500">Start Date</label><div>DATA</div>
				<label class="text-gray-500">End Date</label><div>DATA</div>
			</div>
		</section>
		<section class="bg-white border rounded-lg shadow p-6">
			<h3 class="font-semibold text-center">Fines and Violations</h3>
			<div class="mt-4 grid grid-cols-2 gap-3 text-sm">
				<label class="text-gray-500">Violation 1</label><div>—</div>
				<label class="text-gray-500">Reason</label><div>—</div>
				<label class="text-gray-500">Amount</label><div>—</div>
				<label class="text-gray-500">Date Issued</label><div>—</div>
			</div>
		</section>
	</div>
</div>
@endsection


