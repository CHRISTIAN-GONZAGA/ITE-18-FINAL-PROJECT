<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>TraMo</title>
	@if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
		@vite(['resources/css/app.css', 'resources/js/app.js'])
	@endif
</head>
<body class="min-h-screen bg-[#FDFDFC] text-[#1b1b18]">
	<header class="bg-[#1b1b18] text-white">
		<div class="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
			<a href="{{ route('tramo.home') }}" class="font-semibold">Logo</a>
			<nav class="flex items-center gap-5 text-sm">
				<a href="{{ route('tramo.home') }}" class="hover:underline">Home</a>
				<a href="#about" class="hover:underline">About</a>
				<form action="{{ route('tramo.vehicle') }}" method="get" class="hidden md:block">
					<input name="q" placeholder="Search by PLATE NUMBER" class="rounded-sm text-black px-3 py-1.5 w-64" />
				</form>
			</nav>
		</div>
		<!-- Page navigation buttons -->
		<nav class="bg-white text-[#1b1b18] border-t border-[#e3e3e0]">
			<div class="max-w-6xl mx-auto px-4 py-2 flex flex-wrap gap-2 text-sm">
				<a href="{{ route('tramo.home') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Home</a>
				<a href="{{ route('tramo.vehicle') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Vehicle Details</a>
				<a href="{{ route('tramo.vehicle.create') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Add Vehicle</a>
				<a href="{{ route('tramo.role') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Pick Role</a>
				<a href="{{ route('tramo.login.customer') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Customer Login</a>
				<a href="{{ route('tramo.login.admin') }}" class="px-3 py-1.5 border rounded-sm hover:bg-gray-100">Admin Login</a>
			</div>
		</nav>
	</header>

	<main class="max-w-6xl mx-auto p-4">
		@yield('content')
	</main>

	<footer class="py-10"></footer>
</body>
</html>


