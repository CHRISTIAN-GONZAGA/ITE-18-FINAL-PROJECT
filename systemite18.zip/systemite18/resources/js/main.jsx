import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import '../css/app.css'
import App from './tramo/App'
import Home from './tramo/pages/Home'
import RoleSelection from './tramo/pages/RoleSelection'
import VehicleForm from './tramo/pages/VehicleForm'
import VehicleDetails from './tramo/pages/VehicleDetails'
import VehicleSearch from './tramo/pages/VehicleSearch'
import ViolationGuide from './tramo/pages/ViolationGuide'
import Dashboard from './tramo/pages/Dashboard'
import Login from './tramo/pages/Login'
import OwnerForm from './tramo/pages/OwnerForm'
import InsuranceForm from './tramo/pages/InsuranceForm'
import FineForm from './tramo/pages/FineForm'
import About from './tramo/pages/About'
import Services from './tramo/pages/Services'
import Contact from './tramo/pages/Contact'

const router = createBrowserRouter(
  [
    { path: '/', element: <App />, children: [
    { index: true, element: <Home /> },
    { path: '/role', element: <RoleSelection /> },
    { path: '/vehicle', element: <VehicleForm /> },
    { path: '/vehicle/new', element: <VehicleForm /> },
    { path: '/vehicle/search', element: <VehicleSearch /> },
    { path: '/vehicle/:plate', element: <VehicleDetails /> },
    { path: '/violation-guide', element: <ViolationGuide /> },
    { path: '/dashboard', element: <Dashboard /> },
    { path: '/login', element: <Login /> },
    { path: '/owner', element: <OwnerForm /> },
    { path: '/insurance', element: <InsuranceForm /> },
    { path: '/fine', element: <FineForm /> },
    { path: '/about', element: <About /> },
    { path: '/services', element: <Services /> },
    { path: '/contact', element: <Contact /> },
    { path: '*', element: <Home /> },
  ]},
  ],
  {
    future: {
      v7_startTransition: true,
      v7_relativeSplatPath: true,
    },
  }
)

const rootEl = document.getElementById('app')
if (rootEl) {
  ReactDOM.createRoot(rootEl).render(
    <React.StrictMode>
      <RouterProvider router={router} />
    </React.StrictMode>
  )
}
