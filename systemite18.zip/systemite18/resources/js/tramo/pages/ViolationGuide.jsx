import { useNavigate } from 'react-router-dom'

export default function ViolationGuide() {
  const navigate = useNavigate()

  return (
    <div className="pt-20 pb-12 animate-fade-in min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <button
            onClick={() => navigate(-1)}
            className="mb-6 inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-semibold transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Vehicle Details
          </button>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
            Fines and Violation Information
          </h1>
          <p className="text-gray-600 text-lg">Complete guide on how to handle traffic violations</p>
        </div>

        {/* Content */}
        <div className="space-y-8">
          {/* Section 1: Speeding */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border-l-4 border-red-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-red-500 to-rose-600 p-3 rounded-xl">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800">1. SPEEDING</h2>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">What?</h3>
              <p className="text-gray-600">Driving above the allowed speed limit or too fast for conditions.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-700 mb-3">Steps:</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600">
                <li>Keep the ticket (OVR).</li>
                <li>Check who issued it (LTO/MMDA/City).</li>
                <li>Prepare: Valid ID, Driver's License, OR/CR.</li>
                <li>Visit the issuing office and pay the fine OR file a contest (bring evidence like dashcam).</li>
                <li>Claim Official Receipt as proof of settlement.</li>
              </ol>
            </div>
          </div>

          {/* Section 2: Driving Without License */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border-l-4 border-amber-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-amber-500 to-orange-600 p-3 rounded-xl">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800">2. DRIVING WITHOUT LICENSE / EXPIRED LICENSE / WRONG LICENSE CLASS</h2>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">What?</h3>
              <p className="text-gray-600">Operating a motor vehicle without carrying a valid license or using the wrong license type.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-700 mb-3">Steps:</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600">
                <li>Keep the ticket.</li>
                <li>Bring ID and (if you have it) your actual license.</li>
                <li>If expired, renew your license first at LTO.</li>
                <li>Pay violation at issuing office.</li>
                <li>Get Official Receipt.</li>
              </ol>
            </div>
          </div>

          {/* Section 3: No Helmet */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border-l-4 border-blue-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-xl">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800">3. NO HELMET (Motorcycle rider or backrider)</h2>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">What?</h3>
              <p className="text-gray-600">Riding without a standard motorcycle helmet.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-700 mb-3">Steps:</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600">
                <li>Keep the ticket.</li>
                <li>Prepare: ID, License, OR/CR, and your helmet (some offices verify).</li>
                <li>Go to issuing office — pay the violation.</li>
                <li>Get Official Receipt.</li>
              </ol>
            </div>
          </div>

          {/* Section 4: Expired Registration */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border-l-4 border-purple-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-xl">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800">4. EXPIRED OR NO VEHICLE REGISTRATION</h2>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">What?</h3>
              <p className="text-gray-600">Using an unregistered vehicle or failing to carry OR/CR.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-700 mb-3">Steps:</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600">
                <li>Keep the ticket.</li>
                <li>Gather documents: OR/CR, CTPL insurance, valid ID.</li>
                <li>Renew registration at LTO if expired.</li>
                <li>Pay violation fine at issuing office.</li>
                <li>Keep receipts for both renewal and violation.</li>
              </ol>
            </div>
          </div>

          {/* Universal Checklist */}
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-xl p-6 md:p-8 text-white">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold">UNIVERSAL CHECKLIST</h2>
            </div>
            <p className="text-indigo-100 mb-4 text-lg">(WORKS FOR ALL VIOLATIONS)</p>
            <ol className="list-decimal list-inside space-y-3 text-lg">
              <li>Keep the ticket (OVR).</li>
              <li>Identify which agency issued it.</li>
              <li>Prepare needed documents:
                <ul className="list-disc list-inside ml-6 mt-2 space-y-1 text-indigo-100">
                  <li>Valid ID</li>
                  <li>Driver's License</li>
                  <li>OR/CR</li>
                  <li>Authorization letter if not the owner</li>
                </ul>
              </li>
              <li>Go to correct office (LTO / MMDA / City Hall)</li>
              <li>Pay OR contest within the allowed period</li>
              <li>Get Official Receipt as proof</li>
            </ol>
          </div>

          {/* Government Agencies */}
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 text-center mb-6">Government Agencies Concerned</h2>

            {/* LTO */}
            <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-600 p-3 rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-gray-800">LAND TRANSPORTATION OFFICE (LTO)</h3>
              </div>
              <div>
                <h4 className="font-semibold text-gray-700 mb-2">Where to Settle:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-600 ml-4">
                  <li>Any LTO District Office</li>
                  <li>LTO Law Enforcement & Traffic Adjudication Service (LETAS)</li>
                  <li>LTO Cashier Section for payment</li>
                  <li>Some violations may be settled at the LTO Regional Office depending on complexity (e.g., contested violations)</li>
                </ul>
              </div>
            </div>

            {/* CTTMD */}
            <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-gray-800">City Transportation & Traffic Management Department (CTTMD)</h3>
              </div>
              <div>
                <h4 className="font-semibold text-gray-700 mb-2">Where to Settle:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-600 ml-4">
                  <li>Any CTTMD District Office</li>
                  <li>CTTMD Enforcement & Adjudication Unit</li>
                  <li>CTTMD Cashier Section for payment</li>
                  <li>Some violations may be settled at the CTTMD Regional Office depending on complexity (e.g., contested violations)</li>
                </ul>
              </div>
            </div>

            {/* PNP/HPG */}
            <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-r from-red-500 to-rose-600 p-3 rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-gray-800">PNP / Highway Patrol Group (HPG)</h3>
              </div>
              <div>
                <h4 className="font-semibold text-gray-700 mb-2">Where to Settle:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-600 ml-4">
                  <li>PNP Station where case was recorded</li>
                  <li>HPG Provincial/District Office if they issued the citation</li>
                  <li>LTO District Office for administrative penalties for accidents</li>
                  <li>PNP Investigation Section</li>
                  <li>Traffic Accident Investigation Unit (TAIU)</li>
                  <li>Settlement may also involve court in severe cases</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Button */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate(-1)}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all font-semibold text-lg"
          >
            Back to Vehicle Details
          </button>
        </div>
      </div>
    </div>
  )
}

