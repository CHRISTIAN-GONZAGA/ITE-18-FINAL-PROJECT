import { useState } from 'react'
import http from '../api/http'

export default function VehicleInfo() {
  const [form, setForm] = useState({
    owner_id: '', vin: '', make: '', model: '', color: '', year: '', vehicle_status: 'Active', pin: ''
  })
  const [result, setResult] = useState({ ok: false, msg: '' })
  const [loading, setLoading] = useState(false)

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  async function onSubmit(e) {
    e.preventDefault()
    setResult({ ok: false, msg: '' })
    setLoading(true)
    try {
      const payload = { ...form, year: parseInt(form.year, 10) }
      const { data } = await http.post('/create-vehicle', payload)
      if (data?.success) {
        setResult({ ok: true, msg: 'Vehicle created successfully!' })
        setForm({ owner_id: '', vin: '', make: '', model: '', color: '', year: '', vehicle_status: 'Active', pin: '' })
      } else {
        setResult({ ok: false, msg: data?.message || 'Failed to create vehicle' })
      }
    } catch (err) {
      const msg = err?.response?.data?.message || 'Failed to create vehicle'
      setResult({ ok: false, msg })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="pt-20 pb-12 animate-fade-in">
      <form onSubmit={onSubmit} className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-block animate-float">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-full blur-2xl opacity-50 animate-pulse"></div>
              <div className="relative bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-600 p-5 rounded-full shadow-2xl">
                <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
            </div>
          </div>
          <h1 className="text-5xl font-extrabold gradient-text-animated">
            Create New Vehicle
          </h1>
          <p className="text-xl text-gray-600">Add a new vehicle to the system with comprehensive details</p>
        </div>

        {/* Form Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Owner & Identity Card */}
          <div className="relative glass rounded-[2rem] p-8 shadow-2xl border border-white/20 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-teal-600/10"></div>
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-emerald-600">
                <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-3 rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                Owner & Identity
              </h2>
              <div className="space-y-4">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                  <input
                    name="owner_id"
                    value={form.owner_id}
                    onChange={update}
                    placeholder="Owner ID (existing)"
                    className="relative w-full border-2 border-emerald-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all shadow-lg"
                    required
                  />
                </div>
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                  <input
                    name="vin"
                    value={form.vin}
                    onChange={update}
                    placeholder="VIN (17 characters)"
                    maxLength={17}
                    className="relative w-full border-2 border-emerald-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all shadow-lg"
                    required
                  />
                </div>
                <div className="relative">
                  <label className="block text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    Security PIN
                    <span className="text-xs text-gray-500 font-normal">(Required for public access)</span>
                  </label>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                    <input
                      name="pin"
                      type="text"
                      value={form.pin}
                      onChange={update}
                      placeholder="Enter 4-10 digit PIN (e.g., 1234)"
                      maxLength={10}
                      pattern="[0-9]*"
                      className="relative w-full border-2 border-blue-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-blue-500/50 focus:border-blue-500 transition-all shadow-lg"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Regular users will need this PIN to search for this vehicle
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Vehicle Specs Card */}
          <div className="relative glass rounded-[2rem] p-8 shadow-2xl border border-white/20 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-500/10 to-cyan-600/10"></div>
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-teal-600">
                <div className="bg-gradient-to-r from-teal-600 to-cyan-600 p-3 rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                Vehicle Specs
              </h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                    <input
                      name="make"
                      value={form.make}
                      onChange={update}
                      placeholder="Make"
                      className="relative w-full border-2 border-teal-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-lg"
                      required
                    />
                  </div>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                    <input
                      name="model"
                      value={form.model}
                      onChange={update}
                      placeholder="Model"
                      className="relative w-full border-2 border-teal-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-lg"
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                    <input
                      name="color"
                      value={form.color}
                      onChange={update}
                      placeholder="Color"
                      className="relative w-full border-2 border-teal-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-lg"
                      required
                    />
                  </div>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                    <input
                      type="number"
                      name="year"
                      value={form.year}
                      onChange={update}
                      placeholder="Year"
                      min="1900"
                      max={new Date().getFullYear() + 1}
                      className="relative w-full border-2 border-teal-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-lg"
                      required
                    />
                  </div>
                </div>
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                  <select
                    name="vehicle_status"
                    value={form.vehicle_status}
                    onChange={update}
                    className="relative w-full border-2 border-teal-200 bg-white/90 backdrop-blur-sm rounded-xl p-4 focus:ring-4 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-lg"
                  >
              <option>Active</option>
              <option>Inactive</option>
              <option>Sold</option>
              <option>Stolen</option>
            </select>
          </div>
        </div>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-center pt-4">
          <button
            type="submit"
            disabled={loading}
            className="relative group bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white px-12 py-5 rounded-2xl shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-3">
              {loading ? (
                <>
                  <svg className="animate-spin h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating...
                </>
              ) : (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Create Vehicle
                </>
              )}
            </span>
            <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"></div>
          </button>
      </div>

        {/* Result Message */}
      {result.msg && (
          <div className={`relative rounded-2xl p-6 border-2 shadow-xl animate-scale-in ${
            result.ok
              ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 text-green-800'
              : 'bg-gradient-to-r from-red-50 to-pink-50 border-red-200 text-red-800'
          }`}>
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-xl ${result.ok ? 'bg-green-500' : 'bg-red-500'}`}>
                {result.ok ? (
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                )}
              </div>
              <span className="font-bold text-lg">{result.msg}</span>
            </div>
          </div>
      )}
    </form>
    </div>
  )
}
