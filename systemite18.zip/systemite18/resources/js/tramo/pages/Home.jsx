import { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'

function Card({ title, desc, to, icon, gradient, delay = 0 }) {
  return (
    <Link 
      to={to} 
      className={`group relative bg-white/80 backdrop-blur-lg rounded-3xl p-8 shadow-xl hover:shadow-2xl transform hover:scale-105 hover:-translate-y-2 transition-all duration-500 border border-white/20 overflow-hidden ${gradient}`}
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Animated Background Gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
      
      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-[1]"></div>
      
      {/* Shimmer Effect */}
      <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 shimmer"></div>
      
      <div className="relative z-10">
        <div className="text-6xl mb-4 transform group-hover:scale-125 group-hover:rotate-12 transition-all duration-300">{icon}</div>
        <div className="font-bold text-2xl mb-2 text-gray-800 group-hover:text-white transition-colors">{title}</div>
        <div className="text-gray-600 group-hover:text-white/90 transition-colors">{desc}</div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12 group-hover:scale-150 transition-transform duration-500"></div>
    </Link>
  )
}

export default function Home() {
  const [plate, setPlate] = useState('')
  const [pin, setPin] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    setIsAdmin((localStorage.getItem('role') || '').toUpperCase() === 'ADMIN')
  }, [])

  function onSearch(e) {
    e.preventDefault()
    const p = plate.trim()
    if (p) {
      if (!isAdmin && pin) {
        navigate(`/vehicle/${encodeURIComponent(p)}?pin=${encodeURIComponent(pin)}`)
      } else if (isAdmin) {
        navigate(`/vehicle/${encodeURIComponent(p)}`)
      } else {
        alert('Please enter the vehicle PIN to search')
      }
    }
  }

  return (
    <div className="space-y-20 animate-fade-in pt-20">
      {/* Hero Section */}
      <section className="relative">
        <div className="relative glass rounded-[3rem] p-10 md:p-16 text-center overflow-hidden shadow-2xl border border-white/20">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, rgba(99, 102, 241, 0.5) 1px, transparent 0)`,
              backgroundSize: '40px 40px'
            }}></div>
          </div>
          
          <div className="relative z-10 max-w-5xl mx-auto space-y-8">
            {/* Animated Icon */}
            <div className="inline-block animate-float">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-2xl opacity-50 animate-pulse"></div>
                <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 p-6 rounded-full shadow-2xl">
                  <svg className="w-20 h-20 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
            </div>
            
            <div>
              <h1 className="text-5xl md:text-7xl font-extrabold mb-4">
                <span className="gradient-text-animated">Welcome to TraMo</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
                Track and manage vehicle information with ease. Search by plate number to access comprehensive vehicle details instantly.
              </p>
            </div>

            {/* Search Form */}
            <form onSubmit={onSearch} className="max-w-3xl mx-auto mt-12">
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity"></div>
                    <input
                      className="relative w-full border-2 border-blue-200 bg-white/90 backdrop-blur-sm rounded-2xl p-5 text-lg focus:ring-4 focus:ring-blue-500/50 focus:border-blue-500 transition-all shadow-lg"
                      placeholder="Enter plate number (e.g., ABC-1234)"
                      value={plate}
                      onChange={e=>setPlate(e.target.value)}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="relative group bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white px-10 py-5 rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 font-bold text-lg overflow-hidden"
                  >
                    <span className="relative z-10 flex items-center gap-3">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                      Search
                    </span>
                    <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
                  </button>
                </div>
                
                {!isAdmin && (
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-indigo-600/20 rounded-2xl blur-xl"></div>
                    <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-blue-200">
                      <label className="block text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                          </svg>
                        </div>
                        Security PIN
                      </label>
                      <input
                        type="text"
                        pattern="[0-9]*"
                        maxLength={10}
                        className="w-full border-2 border-blue-200 bg-white rounded-xl p-4 text-lg focus:ring-4 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                        placeholder="Enter vehicle PIN (required for security)"
                        value={pin}
                        onChange={e=>setPin(e.target.value.replace(/\D/g, ''))}
                        required={!isAdmin}
                      />
                      <p className="text-sm text-gray-500 mt-2 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Enter the PIN provided for this vehicle
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </form>

            {isAdmin && (
              <div className="flex flex-wrap justify-center gap-4 mt-8">
                <Link
                  to="/dashboard"
                  className="group relative bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-8 py-4 rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 font-bold overflow-hidden"
                >
                  <span className="relative z-10 flex items-center gap-3">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Admin Dashboard
                  </span>
                  <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
                </Link>
                <Link
                  to="/vehicle/search"
                  className="group relative bg-gradient-to-r from-indigo-600 to-blue-600 text-white px-8 py-4 rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 font-bold overflow-hidden"
                >
                  <span className="relative z-10 flex items-center gap-3">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    Manage Vehicles
                  </span>
                  <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
                </Link>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="relative">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-extrabold mb-4 gradient-text-animated">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive vehicle management solutions at your fingertips
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card
            title="Fines and Violations"
            desc="View penalties and traffic violations for any vehicle with detailed history and payment tracking."
            to="/"
            icon="⚖️"
            gradient="from-red-500 to-pink-600"
            delay={0}
          />
          <Card
            title="Insurance"
            desc="Check insurance details, coverage, and expiration status with real-time updates."
            to="/"
            icon="🛡️"
            gradient="from-green-500 to-emerald-600"
            delay={100}
          />
          <Card
            title="Registration"
            desc="Verify registration information and expiry dates with comprehensive documentation."
            to="/"
            icon="📝"
            gradient="from-blue-500 to-cyan-600"
            delay={200}
          />
        </div>
      </section>
    </div>
  )
}
