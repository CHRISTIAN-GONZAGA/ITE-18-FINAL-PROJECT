import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import http from '../api/http'

export default function VehicleSearch() {
  const navigate = useNavigate()
  const [isAdmin, setIsAdmin] = useState(false)
  const [plate, setPlate] = useState('')
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState(null)
  const [msg, setMsg] = useState('')
  const [msgType, setMsgType] = useState('info') // 'success', 'error', 'info'

  // Edit buffers
  const [vehEdit, setVehEdit] = useState({})
  const [ownerEdit, setOwnerEdit] = useState({})
  const [addressEdit, setAddressEdit] = useState({})

  // New related entries
  const [newIns, setNewIns] = useState({ serial_number:'', provider:'', policy_number:'', coverage:'', start_date:'', end_date:'' })
  const [newFine, setNewFine] = useState({ serial_number:'', reason:'', amount:'', issued_date:'', due_date:'' })

  // Edit mode states
  const [editingInsuranceId, setEditingInsuranceId] = useState(null)
  const [editingFineId, setEditingFineId] = useState(null)
  const [editIns, setEditIns] = useState({})
  const [editFine, setEditFine] = useState({})
  
  // Track newly added items (show Delete instead of Edit)
  const [newlyAddedInsuranceIds, setNewlyAddedInsuranceIds] = useState(new Set())
  const [newlyAddedFineIds, setNewlyAddedFineIds] = useState(new Set())

  useEffect(() => {
    setIsAdmin((localStorage.getItem('role') || '').toUpperCase() === 'ADMIN')
  }, [])

  const onInput = (setter) => (e) => setter((s) => ({ ...s, [e.target.name]: e.target.value }))

  function showMessage(message, type = 'info') {
    setMsg(message)
    setMsgType(type)
    setTimeout(() => setMsg(''), 5000)
  }

  async function lookup() {
    if (!isAdmin) { showMessage('Unauthorized', 'error'); return }
    const q = plate.trim()
    if (!q) { showMessage('Enter plate number', 'error'); return }
    setLoading(true); setMsg(''); setData(null)
    try {
      const res = await http.get(`/vehicle/search/${encodeURIComponent(q)}`)
      const item = res?.data?.data || null
      setData(item)
      if (item) {
        setVehEdit({ make: item.make, model: item.model, color: item.color, year: item.year, vehicle_status: item.vehicle_status, pin: item.pin || '' })
        setOwnerEdit({ FName: item.owner?.FName || '', LName: item.owner?.LName || '', PhoneNumber: item.owner?.PhoneNumber || '' })
        setAddressEdit({ 
          street: item.owner?.address?.street || '', 
          city: item.owner?.address?.city || '', 
          province: item.owner?.address?.province || '', 
          postal_code: item.owner?.address?.postal_code || '' 
        })
        showMessage('Vehicle found', 'success')
      } else {
        showMessage('No record found', 'error')
      }
    } catch (e) {
      showMessage(e?.response?.data?.message || 'Lookup failed', 'error')
    } finally { setLoading(false) }
  }

  async function saveVehicle() {
    if (!data?.vehicle_id) return
    try {
      // Remove plate_number from the update payload since it's not part of vehicle update
      const { plate_number, ...vehicleData } = vehEdit
      await http.put(`/update-vehicle/${data.vehicle_id}`, vehicleData)
      showMessage('Vehicle updated successfully', 'success')
      await lookup()
    } catch (e) { showMessage(e?.response?.data?.message || 'Update failed', 'error') }
  }

  async function saveOwner() {
    if (!data?.owner?.owner_id) return
    try {
      await http.put(`/update-owner/${data.owner.owner_id}`, { ...ownerEdit, ...addressEdit })
      showMessage('Owner updated successfully', 'success')
      await lookup()
    } catch (e) { showMessage(e?.response?.data?.message || 'Update failed', 'error') }
  }

  async function addInsurance() {
    if (!data?.vehicle_id) return
    
    // Validate required fields
    if (!newIns.policy_number || !newIns.start_date || !newIns.end_date) {
      showMessage('Please fill in all required fields: Policy Number, Start Date, and End Date', 'error')
      return
    }

    try {
      // Try to parse coverage as number for coverage_amount (backend validation requirement)
      // If it's not a number, use 0 as default
      const coverageAmount = parseFloat(newIns.coverage || '0')
      const validCoverageAmount = isNaN(coverageAmount) || coverageAmount < 0 ? 0 : coverageAmount

      const payload = {
        vehicle_id: data.vehicle_id,
        policy_number: newIns.policy_number,
        start_date: newIns.start_date,
        end_date: newIns.end_date,
        coverage_amount: validCoverageAmount, // Required for backend validation (numeric, default to 0 if text)
        coverage: newIns.coverage || '', // Text/string description for database
        serial_number: newIns.serial_number || null,
        provider: newIns.provider || null,
      }
      
      const response = await http.post('/create-insurance', payload)
      if (response?.data?.success) {
        const insuranceData = response?.data?.data
        const newInsuranceId = insuranceData?.insurance_id
        if (newInsuranceId) {
          // Ensure we store both number and string versions to handle type mismatches
          setNewlyAddedInsuranceIds(prev => {
            const newSet = new Set(prev)
            newSet.add(Number(newInsuranceId))
            newSet.add(String(newInsuranceId))
            return newSet
          })
        }
        showMessage('Insurance added successfully', 'success')
        setNewIns({ serial_number:'', provider:'', policy_number:'', coverage:'', start_date:'', end_date:'' })
        await lookup()
      } else {
        showMessage(response?.data?.message || 'Add insurance failed', 'error')
      }
    } catch (e) {
      const errorData = e?.response?.data
      let errorMsg = 'Add insurance failed'
      
      if (errorData?.message) {
        errorMsg = errorData.message
      } else if (errorData?.errors) {
        // Format validation errors nicely
        const errors = Object.entries(errorData.errors).map(([key, value]) => {
          return `${key}: ${Array.isArray(value) ? value.join(', ') : value}`
        }).join('; ')
        errorMsg = `Validation errors: ${errors}`
      }
      
      showMessage(errorMsg, 'error')
    }
  }

  async function addFine() {
    if (!data?.vehicle_id) return
    
    // Validate required fields
    if (!newFine.reason || !newFine.issued_date || !newFine.due_date || !newFine.amount) {
      showMessage('Please fill in all required fields: Reason, Amount, Issued Date, and Due Date', 'error')
      return
    }

    try {
      const payload = {
        vehicle_id: data.vehicle_id,
        fine_amount: parseFloat(newFine.amount || '0'),
        amount: parseFloat(newFine.amount || '0'), // Also send as amount for model fillable
        issued_date: newFine.issued_date,
        due_date: newFine.due_date,
        violation_type: newFine.reason,
        description: newFine.reason,
        reason: newFine.reason, // Also send as reason for model fillable
        serial_number: newFine.serial_number || null,
      }
      
      const response = await http.post('/create-fine', payload)
      if (response?.data?.success) {
        const fineData = response?.data?.data
        const newFineId = fineData?.fine_id
        if (newFineId) {
          // Ensure we store both number and string versions to handle type mismatches
          setNewlyAddedFineIds(prev => {
            const newSet = new Set(prev)
            newSet.add(Number(newFineId))
            newSet.add(String(newFineId))
            return newSet
          })
        }
        showMessage('Fine added successfully', 'success')
        setNewFine({ serial_number:'', reason:'', amount:'', issued_date:'', due_date:'' })
        await lookup()
      } else {
        showMessage(response?.data?.message || 'Add fine failed', 'error')
      }
    } catch (e) {
      const errorMsg = e?.response?.data?.message || (e?.response?.data?.errors ? JSON.stringify(e.response.data.errors) : 'Add fine failed')
      showMessage(errorMsg, 'error')
    }
  }

  function startEditInsurance(insurance) {
    setEditingInsuranceId(insurance.insurance_id)
    setEditIns({
      serial_number: insurance.serial_number || '',
      provider: insurance.provider || '',
      policy_number: insurance.policy_number || '',
      coverage: insurance.coverage || '',
      start_date: insurance.start_date || '',
      end_date: insurance.end_date || ''
    })
  }

  function cancelEditInsurance() {
    setEditingInsuranceId(null)
    setEditIns({})
  }
  
  async function updateInsurance(id) {
    if (!id) return showMessage('No insurance selected', 'error')
    try {
      await http.put(`/update-insurance/${id}`, { ...editIns })
      showMessage('Insurance updated successfully', 'success')
      setEditingInsuranceId(null)
      setEditIns({})
      // Remove from newly added list since it's been edited (now it's an existing item)
      setNewlyAddedInsuranceIds(prev => {
        const next = new Set(prev)
        next.delete(Number(id))
        next.delete(String(id))
        return next
      })
    await lookup()
  } catch (e) {
      showMessage(e?.response?.data?.message || 'Update insurance failed', 'error')
    }
  }

  function startEditFine(fine) {
    setEditingFineId(fine.fine_id)
    setEditFine({
      serial_number: fine.serial_number || '',
      reason: fine.reason || '',
      amount: fine.amount || '',
      issued_date: fine.issued_date || '',
      due_date: fine.due_date || ''
    })
  }

  function cancelEditFine() {
    setEditingFineId(null)
    setEditFine({})
  }

  async function updateFine(id) {
    if (!id) return showMessage('No fine selected', 'error')
    try {
      await http.put(`/update-fine/${id}`, { ...editFine, amount: parseFloat(editFine.amount || '0') })
      showMessage('Fine updated successfully', 'success')
      setEditingFineId(null)
      setEditFine({})
      // Remove from newly added list since it's been edited (now it's an existing item)
      setNewlyAddedFineIds(prev => {
        const next = new Set(prev)
        next.delete(Number(id))
        next.delete(String(id))
        return next
      })
    await lookup()
  } catch (e) {
      showMessage(e?.response?.data?.message || 'Update fine failed', 'error')
    }
  }

  async function deleteInsurance(id) {
    if (!id) return showMessage('No insurance selected', 'error')
    if (!confirm('Are you sure you want to delete this insurance policy?')) return
    try {
      await http.delete(`/delete-insurance/${id}`)
      showMessage('Insurance deleted successfully', 'success')
      // Remove from newly added list
      setNewlyAddedInsuranceIds(prev => {
        const next = new Set(prev)
        next.delete(Number(id))
        next.delete(String(id))
        return next
      })
      await lookup()
    } catch (e) {
      showMessage(e?.response?.data?.message || 'Delete insurance failed', 'error')
    }
  }

  async function deleteFine(id) {
    if (!id) return showMessage('No fine selected', 'error')
    if (!confirm('Are you sure you want to delete this fine?')) return
    try {
      await http.delete(`/delete-fine/${id}`)
      showMessage('Fine deleted successfully', 'success')
      // Remove from newly added list
      setNewlyAddedFineIds(prev => {
        const next = new Set(prev)
        next.delete(Number(id))
        next.delete(String(id))
        return next
      })
      await lookup()
    } catch (e) {
      showMessage(e?.response?.data?.message || 'Delete fine failed', 'error')
    }
  }

  if (!isAdmin) return (
    <div className="text-center py-20">
      <div className="inline-block p-4 bg-red-100 rounded-full mb-4">
        <svg className="w-16 h-16 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      </div>
      <h2 className="text-2xl font-bold text-gray-800 mb-2">Unauthorized Access</h2>
      <p className="text-gray-600">Admin access required</p>
    </div>
  )

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Vehicle Management
          </h1>
          <p className="text-gray-600 mt-1">Search and manage vehicle records</p>
        </div>
      </div>

      <div className="bg-gradient-to-br from-white to-indigo-50 shadow-xl rounded-2xl p-6 border border-indigo-100">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
          <input
            name="plate"
            value={plate}
            onChange={e=>setPlate(e.target.value)}
            onKeyPress={e => e.key === 'Enter' && lookup()}
            placeholder="Enter Plate Number"
            className="w-full border-2 border-indigo-200 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
          />
          <button
            onClick={lookup}
            disabled={loading}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-semibold"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Searching...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Search
              </>
            )}
          </button>
        </div>
        {msg && (
          <div className={`mt-4 rounded-xl p-4 border-2 ${
            msgType === 'success' ? 'bg-green-50 border-green-200 text-green-800' :
            msgType === 'error' ? 'bg-red-50 border-red-200 text-red-800' :
            'bg-blue-50 border-blue-200 text-blue-800'
          }`}>
            <div className="flex items-center gap-2">
              {msgType === 'success' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>}
              {msgType === 'error' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>}
              <span className="font-semibold">{msg}</span>
            </div>
          </div>
        )}
      </div>

      {data && (
        <div className="space-y-6">
          {/* Vehicle and Owner Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-indigo-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Vehicle Details
              </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input name="make" value={vehEdit.make||''} onChange={onInput(setVehEdit)} placeholder="Make" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                <input name="model" value={vehEdit.model||''} onChange={onInput(setVehEdit)} placeholder="Model" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                <input name="color" value={vehEdit.color||''} onChange={onInput(setVehEdit)} placeholder="Color" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                <input type="number" name="year" value={vehEdit.year||''} onChange={onInput(setVehEdit)} placeholder="Year" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-indigo-600 to-blue-600 rounded-lg opacity-0 group-hover:opacity-20 blur transition duration-300"></div>
                  <input 
                    name="pin" 
                    type="text" 
                    value={vehEdit.pin||''} 
                    onChange={onInput(setVehEdit)} 
                    placeholder="Security PIN (4-10 digits)" 
                    maxLength={10}
                    pattern="[0-9]*"
                    className="relative w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                  />
                </div>
                <select name="vehicle_status" value={vehEdit.vehicle_status||''} onChange={onInput(setVehEdit)} className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                  <option>Active</option>
                  <option>Inactive</option>
                  <option>Sold</option>
                  <option>Stolen</option>
                </select>
              </div>
              <button onClick={saveVehicle} className="mt-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all font-semibold">
                Update Vehicle
              </button>
            </div>

            <div className="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-indigo-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                Owner Details
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">Personal Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input name="FName" value={ownerEdit.FName||''} onChange={onInput(setOwnerEdit)} placeholder="First Name" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                    <input name="LName" value={ownerEdit.LName||''} onChange={onInput(setOwnerEdit)} placeholder="Last Name" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                    <input name="PhoneNumber" value={ownerEdit.PhoneNumber||''} onChange={onInput(setOwnerEdit)} placeholder="Phone Number" className="w-full md:col-span-2 border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">Address Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input name="street" value={addressEdit.street||''} onChange={onInput(setAddressEdit)} placeholder="Street Address" className="w-full md:col-span-2 border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                    <input name="city" value={addressEdit.city||''} onChange={onInput(setAddressEdit)} placeholder="City" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                    <input name="province" value={addressEdit.province||''} onChange={onInput(setAddressEdit)} placeholder="Province" className="w-full border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                    <input name="postal_code" value={addressEdit.postal_code||''} onChange={onInput(setAddressEdit)} placeholder="Postal Code" className="w-full md:col-span-2 border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition" />
                  </div>
                </div>
              </div>
              <button onClick={saveOwner} className="mt-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all font-semibold">
                Update Owner
              </button>
            </div>
          </div>

          {/* Insurance Section */}
          <div className="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-emerald-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Insurance Policies
            </h2>
            
            {/* Existing Insurance Policies */}
            {data.insurance && data.insurance.length > 0 && (
              <div className="mb-6 space-y-3">
                {data.insurance.map((ins) => (
                  <div key={ins.insurance_id} className="border-2 border-gray-200 rounded-xl p-4 hover:border-emerald-300 transition">
                    {editingInsuranceId === ins.insurance_id ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <input name="serial_number" value={editIns.serial_number} onChange={onInput(setEditIns)} placeholder="Serial Number" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input name="provider" value={editIns.provider} onChange={onInput(setEditIns)} placeholder="Provider" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input name="policy_number" value={editIns.policy_number} onChange={onInput(setEditIns)} placeholder="Policy Number" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input name="coverage" value={editIns.coverage} onChange={onInput(setEditIns)} placeholder="Coverage" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input type="date" name="start_date" value={editIns.start_date} onChange={onInput(setEditIns)} className="border-2 border-gray-200 rounded-lg p-2" />
                        <input type="date" name="end_date" value={editIns.end_date} onChange={onInput(setEditIns)} className="border-2 border-gray-200 rounded-lg p-2" />
                        <div className="md:col-span-2 flex gap-2">
                          <button onClick={() => updateInsurance(ins.insurance_id)} className="flex-1 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition font-semibold">
                            Save
                          </button>
                          <button onClick={cancelEditInsurance} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500 transition font-semibold">
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm flex-1">
                          <div><span className="font-semibold">Provider:</span> {ins.provider || '-'}</div>
                          <div><span className="font-semibold">Policy #:</span> {ins.policy_number || '-'}</div>
                          <div><span className="font-semibold">Start:</span> {ins.start_date || '-'}</div>
                          <div><span className="font-semibold">End:</span> {ins.end_date || '-'}</div>
                        </div>
                        {(() => {
                          const isNewlyAdded = newlyAddedInsuranceIds.has(Number(ins.insurance_id)) || newlyAddedInsuranceIds.has(String(ins.insurance_id))
                          return isNewlyAdded ? (
                            <button onClick={() => deleteInsurance(ins.insurance_id)} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-semibold">
                              Delete
                            </button>
                          ) : (
                            <button onClick={() => startEditInsurance(ins)} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-semibold">
                              Edit
                            </button>
                          )
                        })()}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Add New Insurance */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-4">
              <h3 className="font-semibold mb-3 text-gray-700">Add New Insurance</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input name="serial_number" value={newIns.serial_number} onChange={onInput(setNewIns)} placeholder="Serial Number" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                <input name="provider" value={newIns.provider} onChange={onInput(setNewIns)} placeholder="Provider" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                <input name="policy_number" value={newIns.policy_number} onChange={onInput(setNewIns)} placeholder="Policy Number" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                <input type="text" name="coverage" value={newIns.coverage} onChange={onInput(setNewIns)} placeholder="Coverage Description (e.g., Full Coverage, Comprehensive)" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                <input type="date" name="start_date" value={newIns.start_date} onChange={onInput(setNewIns)} className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                <input type="date" name="end_date" value={newIns.end_date} onChange={onInput(setNewIns)} className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
            </div>
              <button onClick={addInsurance} className="mt-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all font-semibold">
                Add Insurance
              </button>
            </div>
          </div>

          {/* Fines Section */}
          <div className="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2 text-amber-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Fines & Violations
              </h2>
              <button
                onClick={() => navigate('/violation-guide')}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all font-semibold text-sm"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
                Guide and Walkthrough
              </button>
            </div>
            
            {/* Existing Fines */}
            {data.fines && data.fines.length > 0 && (
              <div className="mb-6 space-y-3">
                {data.fines.map((fine) => (
                  <div key={fine.fine_id} className="border-2 border-gray-200 rounded-xl p-4 hover:border-amber-300 transition">
                    {editingFineId === fine.fine_id ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <input name="serial_number" value={editFine.serial_number} onChange={onInput(setEditFine)} placeholder="Serial Number" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input name="reason" value={editFine.reason} onChange={onInput(setEditFine)} placeholder="Reason" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input type="number" step="0.01" name="amount" value={editFine.amount} onChange={onInput(setEditFine)} placeholder="Amount" className="border-2 border-gray-200 rounded-lg p-2" />
                        <input type="date" name="issued_date" value={editFine.issued_date} onChange={onInput(setEditFine)} className="border-2 border-gray-200 rounded-lg p-2" />
                        <input type="date" name="due_date" value={editFine.due_date} onChange={onInput(setEditFine)} className="border-2 border-gray-200 rounded-lg p-2" />
                        <div className="md:col-span-2 flex gap-2">
                          <button onClick={() => updateFine(fine.fine_id)} className="flex-1 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition font-semibold">
                            Save
                          </button>
                          <button onClick={cancelEditFine} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500 transition font-semibold">
                            Cancel
                          </button>
            </div>
          </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm flex-1">
                          <div><span className="font-semibold">Reason:</span> {fine.reason || '-'}</div>
                          <div><span className="font-semibold">Amount:</span> ${fine.amount || '0'}</div>
                          <div><span className="font-semibold">Issued:</span> {fine.issued_date || '-'}</div>
                          <div><span className="font-semibold">Due:</span> {fine.due_date || '-'}</div>
                        </div>
                        {(() => {
                          const isNewlyAdded = newlyAddedFineIds.has(Number(fine.fine_id)) || newlyAddedFineIds.has(String(fine.fine_id))
                          return isNewlyAdded ? (
                            <button onClick={() => deleteFine(fine.fine_id)} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-semibold">
                              Delete
                            </button>
                          ) : (
                            <button onClick={() => startEditFine(fine)} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-semibold">
                              Edit
                            </button>
                          )
                        })()}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Add New Fine */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-4">
              <h3 className="font-semibold mb-3 text-gray-700">Add New Fine</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input name="serial_number" value={newFine.serial_number} onChange={onInput(setNewFine)} placeholder="Serial Number" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500" />
                <input name="reason" value={newFine.reason} onChange={onInput(setNewFine)} placeholder="Reason" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500" />
                <input type="number" step="0.01" name="amount" value={newFine.amount} onChange={onInput(setNewFine)} placeholder="Amount" className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500" />
                <input type="date" name="issued_date" value={newFine.issued_date} onChange={onInput(setNewFine)} className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500" />
                <input type="date" name="due_date" value={newFine.due_date} onChange={onInput(setNewFine)} className="border-2 border-gray-200 rounded-lg p-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500" />
            </div>
              <button onClick={addFine} className="mt-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all font-semibold">
                Add Fine
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

