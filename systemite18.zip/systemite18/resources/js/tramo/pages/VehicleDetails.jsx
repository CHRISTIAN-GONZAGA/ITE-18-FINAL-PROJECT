import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import http from '../api/http'

function InfoCard({ title, icon, children, gradient, delay = 0 }) {
  return (
    <div 
      className="relative glass rounded-[2rem] p-8 shadow-2xl border border-white/20 overflow-hidden animate-scale-in hover-lift"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 hover:opacity-10 transition-opacity duration-500`}></div>
      <div className="relative z-10">
        <div className="flex items-center gap-4 mb-6">
          <div className={`bg-gradient-to-br ${gradient} p-4 rounded-xl shadow-lg`}>
            {icon}
          </div>
          <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        </div>
        {children}
      </div>
    </div>
  )
}

function InfoField({ label, value, icon, className = '' }) {
  return (
    <div className={`flex items-start gap-3 p-4 bg-white/50 backdrop-blur-sm rounded-xl border border-white/50 ${className}`}>
      {icon && (
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-2 rounded-lg mt-0.5">
          <div className="text-white text-sm">{icon}</div>
        </div>
      )}
      <div className="flex-1">
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</div>
        <div className="text-base font-semibold text-gray-800">{value || '-'}</div>
      </div>
    </div>
  )
}

function StatusBadge({ status }) {
  const statusColors = {
    'Active': 'from-green-500 to-emerald-600',
    'Inactive': 'from-gray-500 to-gray-600',
    'Sold': 'from-blue-500 to-indigo-600',
    'Stolen': 'from-red-500 to-pink-600',
  }
  
  const color = statusColors[status] || 'from-gray-500 to-gray-600'
  
  return (
    <span className={`inline-block bg-gradient-to-r ${color} text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg`}>
      {status}
    </span>
  )
}

export default function VehicleDetails() {
  const { plate } = useParams()
  const navigate = useNavigate()
  const [data, setData] = useState({ loading: true, item: null, msg: '' })
  const [pin, setPin] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    setIsAdmin((localStorage.getItem('role') || '').toUpperCase() === 'ADMIN')
    const urlParams = new URLSearchParams(window.location.search)
    const pinFromUrl = urlParams.get('pin')
    if (pinFromUrl) {
      setPin(pinFromUrl)
    }
  }, [])

  useEffect(() => {
    let ignore = false
    async function load() {
      if (!ignore) setData({ loading: true, item: null, msg: '' })
      
      try {
        let url = `/vehicle/search/${encodeURIComponent(plate)}`
        if (pin && !isAdmin) {
          url += `?pin=${encodeURIComponent(pin)}`
        }
        
        const { data } = await http.get(url)
        if (!ignore) setData({ loading: false, item: data?.data || null, msg: data?.message || '' })
      } catch (err) {
        if (!ignore) {
          const errorMsg = err?.response?.data?.message || 'Failed to load'
          const requiresPin = err?.response?.data?.requires_pin
          
          setData({ 
            loading: false, 
            item: null, 
            msg: errorMsg,
            requiresPin: requiresPin 
          })
        }
      }
    }
    
    if (isAdmin || pin) {
    load()
    } else if (!isAdmin && !pin) {
      setData({ loading: false, item: null, msg: 'PIN is required', requiresPin: true })
    }
    
    return () => { ignore = true }
  }, [plate, pin, isAdmin])

  if (data.loading) return (
    <div className="flex items-center justify-center min-h-screen pt-20 pb-20">
      <div className="text-center animate-fade-in">
        <div className="relative inline-block mb-8">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-2xl opacity-50 animate-pulse"></div>
          <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 p-6 rounded-full shadow-2xl">
            <svg className="animate-spin h-16 w-16 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        </div>
        <h3 className="text-2xl font-bold gradient-text-animated mb-2">Loading Vehicle Information</h3>
        <p className="text-gray-600 text-lg">Please wait while we fetch the details...</p>
      </div>
    </div>
  )

  if (data.requiresPin && !pin && !isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen pt-20 pb-20 animate-fade-in">
        <div className="max-w-md w-full mx-4">
          <div className="relative glass rounded-[3rem] p-10 shadow-2xl border border-white/20 text-center">
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-pink-600/10"></div>
            <div className="relative z-10">
              <div className="inline-block animate-float mb-6">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-pink-600 rounded-full blur-2xl opacity-50"></div>
                  <div className="relative bg-gradient-to-br from-red-500 via-pink-600 to-rose-600 p-5 rounded-full shadow-2xl">
                    <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                </div>
              </div>
              <h2 className="text-3xl font-extrabold mb-3 gradient-text">PIN Required</h2>
              <p className="text-gray-600 mb-8 text-lg">Enter the vehicle PIN to access this information</p>
              <div className="space-y-4">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-pink-600 rounded-2xl blur-lg opacity-20 group-hover:opacity-30 transition-opacity"></div>
                  <input
                    type="text"
                    pattern="[0-9]*"
                    maxLength={10}
                    value={pin}
                    onChange={e => setPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter Vehicle PIN"
                    className="relative w-full border-2 border-red-200 bg-white/90 backdrop-blur-sm rounded-2xl p-5 text-lg focus:ring-4 focus:ring-red-500/50 focus:border-red-500 transition-all shadow-lg"
                  />
                </div>
                <button
                  onClick={() => {
                    if (pin.trim()) {
                      const newUrl = `${window.location.pathname}?pin=${encodeURIComponent(pin)}`
                      window.history.pushState({}, '', newUrl)
                      window.location.reload()
                    }
                  }}
                  className="w-full relative group bg-gradient-to-r from-red-600 via-pink-600 to-rose-600 text-white px-8 py-5 rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all font-bold text-lg overflow-hidden"
                >
                  <span className="relative z-10 flex items-center justify-center gap-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Submit PIN
                  </span>
                  <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"></div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!data.item) {
    // Regular User - Simple "not registered" message with try again
    if (!isAdmin) {
      return (
        <div className="flex items-center justify-center min-h-screen pt-20 pb-20 animate-fade-in">
          <div className="max-w-lg mx-auto text-center">
            <div className="glass rounded-[3rem] p-10 md:p-12 shadow-2xl border border-white/20">
              <div className="inline-block mb-8 animate-float">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 rounded-full blur-2xl opacity-50"></div>
                  <div className="relative bg-gradient-to-br from-orange-500 via-red-600 to-pink-600 p-6 rounded-full shadow-2xl">
                    <svg className="w-20 h-20 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                </div>
              </div>
              <h2 className="text-4xl font-extrabold mb-4 gradient-text">Plate Number Not Registered</h2>
              <p className="text-lg text-gray-600 mb-6">
                The plate number <span className="font-mono font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-lg">{plate}</span> is not registered in the system.
              </p>
              <div className="space-y-4">
                <button
                  onClick={() => navigate('/dashboard')}
                  className="w-full relative group bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all font-bold text-lg overflow-hidden"
                >
                  <span className="relative z-10 flex items-center justify-center gap-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Try Again
                  </span>
                  <div className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"></div>
                </button>
                <p className="text-sm text-gray-500">
                  Please verify the plate number and PIN, then try searching again.
                </p>
              </div>
            </div>
          </div>
        </div>
      )
    }
    
    // Admin - Simple not found message
    return (
      <div className="flex items-center justify-center min-h-screen pt-20 pb-20 animate-fade-in">
        <div className="text-center">
          <div className="inline-block mb-8 animate-float">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-gray-600 to-gray-800 rounded-full blur-2xl opacity-50"></div>
              <div className="relative bg-gradient-to-br from-gray-500 via-gray-600 to-gray-700 p-6 rounded-full shadow-2xl">
                <svg className="w-20 h-20 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
          <h2 className="text-4xl font-extrabold mb-4 gradient-text">No Record Found</h2>
          <p className="text-xl text-gray-600 max-w-md mx-auto mb-6">{data.msg || 'No record found for this plate number.'}</p>
          <button
            onClick={() => navigate('/vehicle/search')}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-4 rounded-2xl hover:shadow-xl transform hover:scale-105 transition-all font-bold text-lg"
          >
            Search Another Vehicle
          </button>
        </div>
      </div>
    )
  }

  const v = data.item
  const reg = (v.registrations || [])[0]
  const ins = (v.insurance || [])[0]

  return (
    <div className="pt-20 pb-12 animate-fade-in">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="inline-block animate-float mb-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-2xl opacity-50 animate-pulse"></div>
            <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 p-6 rounded-full shadow-2xl">
              <svg className="w-20 h-20 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
          </div>
        </div>
        <h1 className="text-5xl font-extrabold mb-4 gradient-text-animated">Vehicle Details</h1>
        <div className="flex items-center justify-center gap-4">
          <div className="text-2xl font-bold text-gray-700">Plate:</div>
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-full text-xl font-bold shadow-lg">
            {reg?.plate_number || plate}
          </div>
          <StatusBadge status={v.vehicle_status} />
        </div>
      </div>

      {/* Vehicle Information Cards */}
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Vehicle & Owner Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <InfoCard 
            title="Vehicle Information" 
            gradient="from-blue-500 to-indigo-600"
            icon={
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            }
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InfoField label="VIN" value={v.vin} icon="🔢" />
              <InfoField label="Make" value={v.make} icon="🏭" />
              <InfoField label="Model" value={v.model} icon="🚗" />
              <InfoField label="Year" value={v.year} icon="📅" />
              <InfoField label="Color" value={v.color} icon="🎨" />
              <InfoField label="Status" value={<StatusBadge status={v.vehicle_status} />} icon="✅" />
            </div>
          </InfoCard>

          <InfoCard 
            title="Owner Information" 
            gradient="from-emerald-500 to-teal-600"
            icon={
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            }
          >
            <div className="space-y-4">
              <InfoField 
                label="Full Name" 
                value={`${v.owner?.FName || ''} ${v.owner?.LName || ''}`.trim()} 
                icon="👤" 
                className="md:col-span-2"
              />
              <InfoField label="Phone Number" value={v.owner?.PhoneNumber} icon="📞" />
              <InfoField label="License Number" value={v.owner?.LicenseNumber} icon="🪪" />
              <InfoField 
                label="Address" 
                value={`${v.owner?.address?.street || ''}, ${v.owner?.address?.city || ''}, ${v.owner?.address?.state || ''} ${v.owner?.address?.zip_code || ''}`.trim()} 
                icon="📍" 
                className="md:col-span-2"
              />
          </div>
          </InfoCard>
        </div>

        {/* Registration & Insurance Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <InfoCard 
            title="Registration Details" 
            gradient="from-purple-500 to-pink-600"
            icon={
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            }
          >
            {reg ? (
              <div className="space-y-4">
                <InfoField label="Plate Number" value={reg.plate_number} icon="🚙" />
                <InfoField label="Registration Number" value={reg.registration_number} icon="📋" />
                <div className="grid grid-cols-2 gap-4">
                  <InfoField label="Start Date" value={reg.registration_date} icon="📅" />
                  <InfoField label="Expiration Date" value={reg.expiration_date} icon="⏰" />
                </div>
                <InfoField label="Status" value={<StatusBadge status={reg.status || 'Active'} />} icon="✅" />
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <svg className="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-lg font-semibold">No Registration Information Available</p>
              </div>
            )}
          </InfoCard>

          <InfoCard 
            title="Insurance Policy" 
            gradient="from-amber-500 to-orange-600"
            icon={
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            }
          >
            {ins ? (
              <div className="space-y-4">
                <InfoField label="Provider" value={ins.provider} icon="🏢" />
                <InfoField label="Policy Number" value={ins.policy_number} icon="📄" />
                <InfoField label="Coverage" value={ins.coverage} icon="🛡️" className="md:col-span-2" />
                <div className="grid grid-cols-2 gap-4">
                  <InfoField label="Start Date" value={ins.start_date} icon="📅" />
                  <InfoField label="End Date" value={ins.end_date} icon="⏰" />
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <svg className="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-lg font-semibold">No Insurance Information Available</p>
          </div>
            )}
          </InfoCard>
        </div>

        {/* Violations/Fines Card */}
        <InfoCard 
          title="Traffic Violations & Fines" 
          gradient="from-red-500 to-rose-600"
          icon={
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          }
        >
          <div className="mb-6 flex justify-end">
            <button
              onClick={() => navigate('/violation-guide')}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all font-semibold"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              Guide and Walkthrough
            </button>
          </div>
          {(!v.fines || v.fines.length === 0) ? (
            <div className="text-center py-12">
              <div className="inline-block p-6 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full mb-4 shadow-lg">
                <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <p className="text-2xl font-bold text-gray-700">No Violations Found</p>
              <p className="text-gray-500 mt-2">This vehicle has a clean record! ✨</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {v.fines.map((f, idx) => (
                <div 
                  key={f.fine_id}
                  className="relative glass-dark rounded-2xl p-6 border border-white/20 overflow-hidden hover-lift group"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/20 rounded-full -mr-12 -mt-12 group-hover:scale-150 transition-transform duration-500"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-gradient-to-r from-red-500 to-rose-600 p-3 rounded-xl shadow-lg">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div className="bg-gradient-to-r from-red-500 to-rose-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                        ${parseFloat(f.amount || 0).toFixed(2)}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <div className="text-xs font-semibold text-gray-400 uppercase mb-1">Violation</div>
                        <div className="text-base font-bold text-white">{f.reason || 'N/A'}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Issued</div>
                          <div className="text-white font-semibold">{f.issued_date || '-'}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Due Date</div>
                          <div className="text-white font-semibold">{f.due_date || '-'}</div>
                        </div>
                      </div>
                      {f.serial_number && (
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Serial #</div>
                          <div className="text-white font-semibold">{f.serial_number}</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </InfoCard>
      </div>
    </div>
  )
}
