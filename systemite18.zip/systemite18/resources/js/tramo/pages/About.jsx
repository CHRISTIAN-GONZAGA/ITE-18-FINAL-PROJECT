export default function About() {
  return (
    <div className="bg-white shadow rounded-2xl p-6">
      <h1 className="text-2xl font-semibold mb-2">About TraMo</h1>
      <p className="text-gray-600">Tracking Made Easy: a vehicle tracking and management system.</p>
    </div>
  )
}
