export default function Services() {
  return (
    <div className="bg-white shadow rounded-2xl p-6">
      <h1 className="text-2xl font-semibold mb-2">Services</h1>
      <ul className="list-disc pl-6 text-gray-700">
        <li>Fines and Violations lookup</li>
        <li>Insurance verification</li>
        <li>Registration validation</li>
      </ul>
    </div>
  )
}
