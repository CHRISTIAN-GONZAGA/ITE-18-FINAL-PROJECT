import { useState } from 'react'
import http from '../api/http'

export default function OwnerForm() {
  const [form, setForm] = useState({ FName: '', LName: '', address_id: '', PhoneNumber: '', LicenseNumber: '' })
  const [result, setResult] = useState({ ok: false, msg: '' })

  function update(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  async function onSubmit(e) {
    e.preventDefault()
    setResult({ ok: false, msg: '' })
    try {
      const { data } = await http.post('/create-owner', { ...form })
      setResult({ ok: !!data?.success, msg: data?.message || (data?.success ? 'Owner created' : 'Failed to create owner') })
    } catch (err) {
      setResult({ ok: false, msg: err?.response?.data?.message || 'Failed to create owner' })
    }
  }

  return (
    <form onSubmit={onSubmit} className="max-w-xl mx-auto space-y-3 bg-white shadow rounded-2xl p-6">
      <h1 className="text-2xl font-semibold mb-2">Create Owner</h1>
      <input name="FName" value={form.FName} onChange={update} placeholder="First Name" className="w-full border rounded-lg p-2" required />
      <input name="LName" value={form.LName} onChange={update} placeholder="Last Name" className="w-full border rounded-lg p-2" required />
      <input name="address_id" value={form.address_id} onChange={update} placeholder="Address ID (existing)" className="w-full border rounded-lg p-2" required />
      <input name="PhoneNumber" value={form.PhoneNumber} onChange={update} placeholder="Phone Number" className="w-full border rounded-lg p-2" required />
      <input name="LicenseNumber" value={form.LicenseNumber} onChange={update} placeholder="License Number" className="w-full border rounded-lg p-2" required />
      <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">Save</button>
      {result.msg && (
        <div className={`${result.ok ? 'text-green-700 bg-green-50 border-green-200' : 'text-red-700 bg-red-50 border-red-200'} border rounded-lg p-3`}>{result.msg}</div>
      )}
    </form>
  )
}
