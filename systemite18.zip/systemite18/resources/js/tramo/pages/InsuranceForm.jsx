import { useState } from 'react'
import http from '../api/http'

export default function InsuranceForm() {
  const [form, setForm] = useState({ vehicle_id: '', policy_number: '', start_date: '', end_date: '', coverage_amount: '' })
  const [result, setResult] = useState({ ok: false, msg: '' })

  function update(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  async function onSubmit(e) {
    e.preventDefault()
    setResult({ ok: false, msg: '' })
    try {
      const payload = { ...form, coverage_amount: parseFloat(form.coverage_amount) }
      const { data } = await http.post('/create-insurance', payload)
      setResult({ ok: !!data?.success, msg: data?.message || (data?.success ? 'Insurance created' : 'Failed to create insurance') })
    } catch (err) {
      setResult({ ok: false, msg: err?.response?.data?.message || 'Failed to create insurance' })
    }
  }

  return (
    <form onSubmit={onSubmit} className="max-w-xl mx-auto space-y-3 bg-white shadow rounded-2xl p-6">
      <h1 className="text-2xl font-semibold mb-2">Create Insurance</h1>
      <input name="vehicle_id" value={form.vehicle_id} onChange={update} placeholder="Vehicle ID" className="w-full border rounded-lg p-2" required />
      <input name="policy_number" value={form.policy_number} onChange={update} placeholder="Policy Number" className="w-full border rounded-lg p-2" required />
      <input type="date" name="start_date" value={form.start_date} onChange={update} className="w-full border rounded-lg p-2" required />
      <input type="date" name="end_date" value={form.end_date} onChange={update} className="w-full border rounded-lg p-2" required />
      <input type="number" step="0.01" name="coverage_amount" value={form.coverage_amount} onChange={update} placeholder="Coverage Amount" className="w-full border rounded-lg p-2" required />
      <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">Save</button>
      {result.msg && (
        <div className={`${result.ok ? 'text-green-700 bg-green-50 border-green-200' : 'text-red-700 bg-red-50 border-red-200'} border rounded-lg p-3`}>{result.msg}</div>
      )}
    </form>
  )
}
