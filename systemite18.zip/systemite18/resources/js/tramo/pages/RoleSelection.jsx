import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function RoleCard({ role, onPick }) {
  return (
    <button onClick={() => onPick(role)} className="w-full bg-white shadow rounded-2xl p-6 text-center transition duration-300 hover:scale-[1.02]">
      <div className="text-2xl font-semibold">{role}</div>
      <div className="text-gray-600 mt-2">Continue as {role.toLowerCase()}</div>
    </button>
  )
}

export default function RoleSelection() {
  const [role, setRole] = useState(null)
  const navigate = useNavigate()

  function pick(r) {
    setRole(r)
    localStorage.setItem('role', r.toUpperCase())
    if (r.toUpperCase() === 'ADMIN') navigate('/vehicle')
    else navigate('/')
  }

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-semibold">Pick your ROLE!</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <RoleCard role="ADMIN" onPick={pick} />
        <RoleCard role="CUSTOMER" onPick={pick} />
      </div>
    </div>
  )
}
