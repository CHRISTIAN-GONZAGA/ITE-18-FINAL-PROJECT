import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import http from '../api/http'

export default function VehicleForm() {
  const navigate = useNavigate()
  const [result, setResult] = useState({ ok: false, msg: '' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const role = (localStorage.getItem('role') || '').toUpperCase()
    if (role !== 'ADMIN') navigate('/')
  }, [navigate])

  // Vehicle Details
  const [vehicle, setVehicle] = useState({ vin:'', make:'', model:'', plate_number:'', year:'', color:'', status:'Active', pin:'' })

  // Owner Details
  const [owner, setOwner] = useState({ first_name:'', last_name:'', phone:'', license_code:'' })
  const [address, setAddress] = useState({ street:'', city:'', province:'', postal_code:'' })

  // Registration Details (Registration Number + dates live under registration table)
  const [registration, setRegistration] = useState({ registration_number:'', registration_date:'', expiration_date:'', status:'Active' })

  // Insurance Details (serial_number collected but DB stores provider/policy/coverage/dates)
  const [insurance, setInsurance] = useState({ serial_number:'', provider:'', policy_number:'', coverage:'', start_date:'', end_date:'' })

  // Violations (quantity controls length, each includes serial_number, reason, amount, issued_date)
  const [violationQty, setViolationQty] = useState(1)
  const [violations, setViolations] = useState([{ serial_number:'', reason:'', amount:'', issued_date:'', due_date:'' }])

  function setQty(n) {
    const qty = Math.max(0, parseInt(n || '0', 10))
    setViolationQty(qty)
    setViolations((prev) => {
      const next = [...prev]
      if (qty > next.length) {
        while (next.length < qty) next.push({ serial_number:'', reason:'', amount:'', issued_date:'', due_date:'' })
      } else if (qty < next.length) {
        next.length = qty
      }
      return next
    })
  }

  const input = (setter) => (e) => setter((s) => ({ ...s, [e.target.name]: e.target.value }))
  const violInput = (idx, field) => (e) => setViolations((arr) => arr.map((v, i) => i === idx ? { ...v, [field]: e.target.value } : v))

  async function onSubmit(e) {
    e.preventDefault()
    setResult({ ok:false, msg:'' })
    setSubmitting(true)
    try {
      // Prepare vehicle object without plate_number (it goes in registration)
      const { plate_number, registration_number, ...vehicleData } = vehicle
      const payload = {
        vehicle: { 
          ...vehicleData, 
          year: parseInt(vehicle.year || '0', 10), 
          status: vehicle.status || 'Active',
          pin: vehicle.pin || null 
        },
        owner: { ...owner, address: { ...address } },
        registration: { 
          plate_number: vehicle.plate_number, 
          registration_number: registration.registration_number || null, 
          registration_date: registration.registration_date, 
          expiration_date: registration.expiration_date, 
          status: registration.status || 'Active' 
        },
        insurance: insurance.provider || insurance.policy_number || insurance.start_date ? { 
          serial_number: insurance.serial_number || null, 
          provider: insurance.provider || null, 
          policy_number: insurance.policy_number || null, 
          coverage: insurance.coverage || null, 
          start_date: insurance.start_date || null, 
          end_date: insurance.end_date || null 
        } : null,
        fines: violations && violations.length ? violations.filter(v => v.reason && v.amount && v.issued_date && v.due_date).map(v => ({ 
          serial_number: v.serial_number || null, 
          reason: v.reason, 
          amount: parseFloat(v.amount || '0'), 
          issued_date: v.issued_date, 
          due_date: v.due_date 
        })) : null,
      }
      const { data } = await http.post('/vehicles', payload)
      if (data?.success) {
        setResult({ ok:true, msg:'Saved successfully.' })
        // Reset form after successful save
        setTimeout(() => {
          setVehicle({ vin:'', make:'', model:'', plate_number:'', year:'', color:'', status:'Active', pin:'' })
          setOwner({ first_name:'', last_name:'', phone:'', license_code:'' })
          setAddress({ street:'', city:'', province:'', postal_code:'' })
          setRegistration({ registration_number:'', registration_date:'', expiration_date:'', status:'Active' })
          setInsurance({ serial_number:'', provider:'', policy_number:'', coverage:'', start_date:'', end_date:'' })
          setViolations([{ serial_number:'', reason:'', amount:'', issued_date:'', due_date:'' }])
          setViolationQty(1)
        }, 2000)
      }
      else setResult({ ok:false, msg:data?.message || 'Failed to save.' })
    } catch (err) {
      const errorMsg = err?.response?.data?.message || 'Failed to save.'
      const errorDetails = err?.response?.data?.errors ? JSON.stringify(err.response.data.errors, null, 2) : ''
      setResult({ ok:false, msg: errorDetails ? `${errorMsg}\n\nValidation errors:\n${errorDetails}` : errorMsg })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <h1 className="text-2xl font-semibold">Vehicle Management</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Vehicle Details */}
        <div className="bg-white shadow rounded-2xl p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Vehicle Details
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input name="vin" value={vehicle.vin} onChange={input(setVehicle)} placeholder="VIN" className="w-full border rounded-lg p-2" required />
            <input name="make" value={vehicle.make} onChange={input(setVehicle)} placeholder="Make" className="w-full border rounded-lg p-2" required />
            <input name="model" value={vehicle.model} onChange={input(setVehicle)} placeholder="Model" className="w-full border rounded-lg p-2" required />
            <input type="number" name="year" value={vehicle.year} onChange={input(setVehicle)} placeholder="Year" className="w-full border rounded-lg p-2" required />
            <input name="color" value={vehicle.color} onChange={input(setVehicle)} placeholder="Color" className="w-full border rounded-lg p-2" required />
            <input name="plate_number" value={vehicle.plate_number} onChange={input(setVehicle)} placeholder="Plate Number" className="w-full border rounded-lg p-2" required />
            <div className="relative group md:col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-lg">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                Security PIN
                <span className="text-xs text-gray-500 font-normal">(Required for public access)</span>
              </label>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg blur opacity-20 group-hover:opacity-30 transition-opacity"></div>
                <input 
                  name="pin" 
                  type="text" 
                  value={vehicle.pin} 
                  onChange={input(setVehicle)} 
                  placeholder="Enter 4-10 digit PIN (e.g., 1234)" 
                  maxLength={10}
                  pattern="[0-9]*"
                  className="relative w-full border-2 border-blue-200 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all" 
                />
              </div>
              <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Regular users will need this PIN to search for this vehicle
              </p>
            </div>
            <input name="registration_number" value={registration.registration_number} onChange={input(setRegistration)} placeholder="Registration Number" className="w-full border rounded-lg p-2" />
            <input type="date" name="registration_date" value={registration.registration_date} onChange={input(setRegistration)} className="w-full border rounded-lg p-2" required />
            <input type="date" name="expiration_date" value={registration.expiration_date} onChange={input(setRegistration)} className="w-full border rounded-lg p-2" required />
          </div>
        </div>

        {/* Owner Details */}
        <div className="bg-white shadow rounded-2xl p-6">
          <h2 className="font-semibold mb-4">Owner Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input name="first_name" value={owner.first_name} onChange={input(setOwner)} placeholder="First Name" className="w-full border rounded-lg p-2" required />
            <input name="last_name" value={owner.last_name} onChange={input(setOwner)} placeholder="Last Name" className="w-full border rounded-lg p-2" required />
            <input name="phone" value={owner.phone} onChange={input(setOwner)} placeholder="Phone Number" className="w-full border rounded-lg p-2" required />
            <input name="license_code" value={owner.license_code} onChange={input(setOwner)} placeholder="License Code" className="w-full border rounded-lg p-2" required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <input name="street" value={address.street} onChange={input(setAddress)} placeholder="Street" className="w-full border rounded-lg p-2" required />
            <input name="city" value={address.city} onChange={input(setAddress)} placeholder="City" className="w-full border rounded-lg p-2" required />
            <input name="province" value={address.province} onChange={input(setAddress)} placeholder="Province" className="w-full border rounded-lg p-2" required />
            <input name="postal_code" value={address.postal_code} onChange={input(setAddress)} placeholder="Postal Code" className="w-full border rounded-lg p-2" required />
          </div>
        </div>

        {/* Insurance Details */}
        <div className="bg-white shadow rounded-2xl p-6">
          <h2 className="font-semibold mb-4">Insurance Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input name="serial_number" value={insurance.serial_number} onChange={input(setInsurance)} placeholder="Serial Number" className="w-full border rounded-lg p-2" />
            <input name="provider" value={insurance.provider} onChange={input(setInsurance)} placeholder="Provider" className="w-full border rounded-lg p-2" />
            <input name="policy_number" value={insurance.policy_number} onChange={input(setInsurance)} placeholder="Policy Number" className="w-full border rounded-lg p-2" />
            <input name="coverage" value={insurance.coverage} onChange={input(setInsurance)} placeholder="Coverage" className="w-full border rounded-lg p-2" />
            <input type="date" name="start_date" value={insurance.start_date} onChange={input(setInsurance)} className="w-full border rounded-lg p-2" />
            <input type="date" name="end_date" value={insurance.end_date} onChange={input(setInsurance)} className="w-full border rounded-lg p-2" />
          </div>
        </div>

        {/* Violations */}
        <div className="bg-white shadow rounded-2xl p-6 md:col-span-2">
          <h2 className="font-semibold mb-4">Violations</h2>
          <div className="flex items-center gap-3 mb-3">
            <label className="text-sm text-gray-600">Quantity</label>
            <input type="number" min="0" value={violationQty} onChange={(e)=>setQty(e.target.value)} className="w-24 border rounded-lg p-2" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {violations.map((v, idx) => (
              <div key={idx} className="border rounded-lg p-3 grid grid-cols-1 md:grid-cols-2 gap-2">
                <input value={v.serial_number} onChange={violInput(idx,'serial_number')} placeholder="Serial Number" className="w-full border rounded-lg p-2" />
                <input value={v.reason} onChange={violInput(idx,'reason')} placeholder="Reason" className="w-full border rounded-lg p-2" />
                <input type="number" step="0.01" value={v.amount} onChange={violInput(idx,'amount')} placeholder="Amount" className="w-full border rounded-lg p-2" />
                <input type="date" value={v.issued_date} onChange={violInput(idx,'issued_date')} className="w-full border rounded-lg p-2" />
                <input type="date" value={v.due_date} onChange={violInput(idx,'due_date')} className="w-full border rounded-lg p-2" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <button disabled={submitting} className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 transition disabled:opacity-60">{submitting ? 'Saving...' : 'Submit'}</button>
      {result.msg && (
        <div className={`${result.ok ? 'text-green-700 bg-green-50 border-green-200' : 'text-red-700 bg-red-50 border-red-200'} border rounded-lg p-3 mt-3`}>{result.msg}</div>
      )}
    </form>
  )
}
