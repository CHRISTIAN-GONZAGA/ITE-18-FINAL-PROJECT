import { useState } from 'react'
import http from '../api/http'

export default function FineForm() {
  const [form, setForm] = useState({ vehicle_id: '', fine_amount: '', issued_date: '', due_date: '', violation_type: '', description: '' })
  const [result, setResult] = useState({ ok: false, msg: '' })

  function update(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  async function onSubmit(e) {
    e.preventDefault()
    setResult({ ok: false, msg: '' })
    try {
      const payload = { ...form, fine_amount: parseFloat(form.fine_amount) }
      const { data } = await http.post('/create-fine', payload)
      setResult({ ok: !!data?.success, msg: data?.message || (data?.success ? 'Fine created' : 'Failed to create fine') })
    } catch (err) {
      setResult({ ok: false, msg: err?.response?.data?.message || 'Failed to create fine' })
    }
  }

  return (
    <form onSubmit={onSubmit} className="max-w-xl mx-auto space-y-3 bg-white shadow rounded-2xl p-6">
      <h1 className="text-2xl font-semibold mb-2">Create Fine</h1>
      <input name="vehicle_id" value={form.vehicle_id} onChange={update} placeholder="Vehicle ID" className="w-full border rounded-lg p-2" required />
      <input type="number" step="0.01" name="fine_amount" value={form.fine_amount} onChange={update} placeholder="Fine Amount" className="w-full border rounded-lg p-2" required />
      <input type="date" name="issued_date" value={form.issued_date} onChange={update} className="w-full border rounded-lg p-2" required />
      <input type="date" name="due_date" value={form.due_date} onChange={update} className="w-full border rounded-lg p-2" required />
      <input name="violation_type" value={form.violation_type} onChange={update} placeholder="Violation Type" className="w-full border rounded-lg p-2" required />
      <textarea name="description" value={form.description} onChange={update} placeholder="Description" className="w-full border rounded-lg p-2" required />
      <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">Save</button>
      {result.msg && (
        <div className={`${result.ok ? 'text-green-700 bg-green-50 border-green-200' : 'text-red-700 bg-red-50 border-red-200'} border rounded-lg p-3`}>{result.msg}</div>
      )}
    </form>
  )
}
