import axios from 'axios'

const http = axios.create({
  baseURL: '/api/v1',
})

http.interceptors.request.use((config) => {
  const token = localStorage.getItem('tramo_token')
  if (token) {
    // Trim token to remove any whitespace
    const cleanToken = token.trim()
    config.headers.Authorization = `Bearer ${cleanToken}`
    config.headers['X-API-Token'] = cleanToken
  }
  return config
})

// Response interceptor to handle token errors
http.interceptors.response.use(
  (response) => response,
  (error) => {
    // If we get a 401 error, the token might be invalid
    if (error.response?.status === 401 && error.response?.data?.message === 'Invalid token') {
      // Clear invalid token and redirect to login
      localStorage.removeItem('tramo_token')
      localStorage.removeItem('role')
      
      // Only redirect if not already on login page
      if (window.location.pathname !== '/login') {
        window.location.href = '/login?expired=true'
      }
    }
    return Promise.reject(error)
  }
)

export default http
