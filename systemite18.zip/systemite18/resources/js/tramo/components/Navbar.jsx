import { NavLink, Link } from 'react-router-dom'
import { useEffect, useState } from 'react'

export default function Navbar() {
  const [isAdmin, setIsAdmin] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  
  // Check authentication status
  const checkAuth = () => {
    const token = localStorage.getItem('tramo_token')
    const role = (localStorage.getItem('role') || '').toUpperCase()
    setIsAdmin(!!token && role === 'ADMIN')
  }
  
  useEffect(() => {
    checkAuth()
    
    // Listen for storage changes (e.g., when login happens in another tab)
    const handleStorageChange = () => checkAuth()
    window.addEventListener('storage', handleStorageChange)
    
    // Also check periodically in case localStorage is updated in same tab
    const interval = setInterval(checkAuth, 1000)
    
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    
    return () => {
      window.removeEventListener('storage', handleStorageChange)
      clearInterval(interval)
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])
  
  // Re-check auth when component might have missed the update
  useEffect(() => {
    const handleFocus = () => checkAuth()
    window.addEventListener('focus', handleFocus)
    return () => window.removeEventListener('focus', handleFocus)
  }, [])

  const link = ({ isActive }) => 
    `px-4 py-2 rounded-xl transition-all duration-300 font-medium relative group ${
      isActive 
        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg scale-105' 
        : 'text-gray-700 hover:text-blue-600 hover:bg-white/50 backdrop-blur-sm'
    }`

  function handleLogout() {
    localStorage.removeItem('tramo_token')
    localStorage.removeItem('role')
    window.location.href = '/'
  }

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'glass backdrop-blur-xl bg-white/80 shadow-xl' 
        : 'bg-white/90 backdrop-blur-md shadow-md'
    }`}>
      <div className="container mx-auto flex items-center justify-between p-4 md:p-6">
        <Link 
          to="/" 
          className="group relative"
        >
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
              <div className="relative bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 px-4 py-2 rounded-xl shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                <span className="font-bold text-2xl text-white tracking-tight">TraMo</span>
              </div>
            </div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-3">
          <NavLink to="/" end className={link}>
            <span className="relative z-10">Home</span>
            <span className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl opacity-0 group-hover:opacity-10 transition-opacity"></span>
          </NavLink>
          <NavLink to="/dashboard" className={link}>
            <span className="relative z-10">Dashboard</span>
            <span className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl opacity-0 group-hover:opacity-10 transition-opacity"></span>
          </NavLink>
          {isAdmin ? (
            <button
              onClick={handleLogout}
              className="px-6 py-2 bg-gradient-to-r from-red-500 via-pink-500 to-rose-600 text-white rounded-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 font-semibold relative overflow-hidden group"
            >
              <span className="relative z-10 flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                Logout
              </span>
              <span className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
            </button>
          ) : (
            <NavLink to="/login" className={link}>
              <span className="relative z-10 flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                </svg>
                Login
              </span>
              <span className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl opacity-0 group-hover:opacity-10 transition-opacity"></span>
            </NavLink>
          )}
        </nav>
      </div>
    </header>
  )
}
