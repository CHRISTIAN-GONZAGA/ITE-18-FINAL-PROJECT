<?php

use Illuminate\Support\Facades\Route;

// React SPA for TraMo UI
Route::view('/', 'app');
Route::view('/role', 'app');
Route::view('/vehicle', 'app');
Route::view('/dashboard', 'app');

// Legacy Blade routes (optional): comment out if not needed
// Route::view('/tramo', 'tramo.home')->name('tramo.home');
// Route::view('/tramo/vehicle', 'tramo.vehicle-details')->name('tramo.vehicle');
// Route::view('/tramo/role', 'tramo.role')->name('tramo.role');
// Route::view('/tramo/login/admin', 'tramo.login-admin')->name('tramo.login.admin');
// Route::view('/tramo/login/customer', 'tramo.login-customer')->name('tramo.login.customer');
// Route::view('/tramo/vehicle/create', 'tramo.vehicle-form')->name('tramo.vehicle.create');
