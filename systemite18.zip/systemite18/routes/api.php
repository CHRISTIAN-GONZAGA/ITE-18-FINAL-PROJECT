<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\VehicleSystemController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\TraMoController;

Route::prefix('v1')->group(function () {
    // ==================== AUTHENTICATION ENDPOINTS ====================
    Route::post('/admin/login', [AuthController::class, 'login']);
    // curl -X POST http://127.0.0.1:8000/api/v1/admin/login \
    //     -H "Content-Type: application/json" \
    //     -d '{
    //             "username": "admin",
    //             "password": "password123"
    //         }'

    Route::post('/admin/logout', [AuthController::class, 'logout']);
    // curl -X POST http://127.0.0.1:8000/api/v1/admin/logout \
    //     -H "Content-Type: application/json" \
    //     -H "Authorization: Bearer your-token-here"

    Route::get('/admin/roles', [AuthController::class, 'getRoles']);
    // curl -X GET http://127.0.0.1:8000/api/v1/admin/roles \
    //     -H "Content-Type: application/json"
    
    // Admin management endpoints (require authentication)
    Route::middleware(['auth.token'])->group(function () {
        Route::post('/admin/create', [AuthController::class, 'createAdmin']);
        // curl -X POST http://127.0.0.1:8000/api/v1/admin/create \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "username": "new-admin",
        //             "password": "password123",
        //             "email": "admin@example.com",
        //             "role_id": 1
        //         }'

        Route::get('/admin/actions', [AuthController::class, 'getAdminActions']);
        // curl -X GET http://127.0.0.1:8000/api/v1/admin/actions \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/admin/profile', [AuthController::class, 'profile']);
        // curl -X GET http://127.0.0.1:8000/api/v1/admin/profile \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
    });

    // ==================== PROTECTED VEHICLE MANAGEMENT ROUTES ====================
    Route::middleware(['auth.token'])->group(function () {
        // ==================== VEHICLE CRUD OPERATIONS ====================
        Route::get('/get-vehicle-list-with-owners', [VehicleSystemController::class, 'getVehicleListWithOwners']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-vehicle-list-with-owners \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::post('/create-vehicle', [VehicleSystemController::class, 'createVehicle']);
        // curl -X POST http://127.0.0.1:8000/api/v1/create-vehicle \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vin": "1HGBH41JXMN109186",
        //             "plate_number": "ABC-1234",
        //             "make": "Honda",
        //             "model": "Civic",
        //             "year": 2020,
        //             "color": "Blue",
        //             "owner_id": 1
        //         }'

        Route::put('/update-vehicle/{vehicleId}', [VehicleSystemController::class, 'updateVehicle']);
        // curl -X PUT http://127.0.0.1:8000/api/v1/update-vehicle/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vin": "1HGBH41JXMN109186",
        //             "plate_number": "ABC-1234",
        //             "make": "Honda",
        //             "model": "Civic",
        //             "year": 2020,
        //             "color": "Red"
        //         }'

        Route::delete('/delete-vehicle/{vehicleId}', [VehicleSystemController::class, 'deleteVehicle']);
        // curl -X DELETE http://127.0.0.1:8000/api/v1/delete-vehicle/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
        
        // ==================== OWNER CRUD OPERATIONS ====================
        Route::get('/get-owner-list', [VehicleSystemController::class, 'getOwnerList']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-owner-list \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-owner-by-id/{ownerId}', [VehicleSystemController::class, 'getOwnerById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-owner-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::post('/create-owner', [VehicleSystemController::class, 'createOwner']);
        // curl -X POST http://127.0.0.1:8000/api/v1/create-owner \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "first_name": "John",
        //             "last_name": "Doe",
        //             "email": "john.doe@example.com",
        //             "phone": "1234567890",
        //             "address": "123 Main St"
        //         }'

        Route::put('/update-owner/{ownerId}', [VehicleSystemController::class, 'updateOwner']);
        // curl -X PUT http://127.0.0.1:8000/api/v1/update-owner/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "first_name": "John",
        //             "last_name": "Doe",
        //             "email": "john.doe@example.com",
        //             "phone": "1234567890",
        //             "address": "456 Oak Ave"
        //         }'

        Route::delete('/delete-owner/{ownerId}', [VehicleSystemController::class, 'deleteOwner']);
        // curl -X DELETE http://127.0.0.1:8000/api/v1/delete-owner/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
        
        // ==================== REGISTRATION CRUD OPERATIONS ====================
        Route::get('/get-registration-list', [VehicleSystemController::class, 'getRegistrationList']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-registration-list \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-registration-by-id/{registrationId}', [VehicleSystemController::class, 'getRegistrationById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-registration-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-registration-list-expiring-soon', [VehicleSystemController::class, 'getRegistrationListExpiringSoon']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-registration-list-expiring-soon \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::post('/create-registration', [VehicleSystemController::class, 'createRegistration']);
        // curl -X POST http://127.0.0.1:8000/api/v1/create-registration \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vehicle_id": 1,
        //             "registration_number": "REG-12345",
        //             "issue_date": "2024-01-01",
        //             "expiry_date": "2025-01-01",
        //             "status": "active"
        //         }'

        Route::put('/update-registration/{registrationId}', [VehicleSystemController::class, 'updateRegistration']);
        // curl -X PUT http://127.0.0.1:8000/api/v1/update-registration/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "registration_number": "REG-12345",
        //             "issue_date": "2024-01-01",
        //             "expiry_date": "2025-12-31",
        //             "status": "active"
        //         }'

        Route::delete('/delete-registration/{registrationId}', [VehicleSystemController::class, 'deleteRegistration']);
        // curl -X DELETE http://127.0.0.1:8000/api/v1/delete-registration/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
        
        // ==================== INSURANCE CRUD OPERATIONS ====================
        Route::get('/get-insurance-list', [VehicleSystemController::class, 'getInsuranceList']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-insurance-list \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-insurance-by-id/{insuranceId}', [VehicleSystemController::class, 'getInsuranceById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-insurance-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-insurance-list-expiring-soon', [VehicleSystemController::class, 'getInsuranceListExpiringSoon']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-insurance-list-expiring-soon \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::post('/create-insurance', [VehicleSystemController::class, 'createInsurance']);
        // curl -X POST http://127.0.0.1:8000/api/v1/create-insurance \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vehicle_id": 1,
        //             "policy_number": "POL-12345",
        //             "provider": "ABC Insurance",
        //             "coverage": "Full coverage up to $50,000",
        //             "start_date": "2024-01-01",
        //             "end_date": "2025-01-01"
        //         }'

        Route::put('/update-insurance/{insuranceId}', [VehicleSystemController::class, 'updateInsurance']);
        // curl -X PUT http://127.0.0.1:8000/api/v1/update-insurance/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "policy_number": "POL-12345",
        //             "provider": "ABC Insurance",
        //             "coverage": "Full coverage up to $60,000",
        //             "start_date": "2024-01-01",
        //             "end_date": "2025-12-31"
        //         }'

        Route::delete('/delete-insurance/{insuranceId}', [VehicleSystemController::class, 'deleteInsurance']);
        // curl -X DELETE http://127.0.0.1:8000/api/v1/delete-insurance/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
        
        // ==================== FINE CRUD OPERATIONS ====================
        Route::get('/get-fine-list', [VehicleSystemController::class, 'getFineList']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-fine-list \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-fine-by-id/{fineId}', [VehicleSystemController::class, 'getFineById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-fine-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-fine-list-overdue', [VehicleSystemController::class, 'getFineListOverdue']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-fine-list-overdue \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::post('/create-fine', [VehicleSystemController::class, 'createFine']);
        // curl -X POST http://127.0.0.1:8000/api/v1/create-fine \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vehicle_id": 1,
        //             "reason": "Speeding",
        //             "amount": 150.00,
        //             "issued_date": "2024-01-15",
        //             "due_date": "2024-02-15"
        //         }'

        Route::put('/update-fine/{fineId}', [VehicleSystemController::class, 'updateFine']);
        // curl -X PUT http://127.0.0.1:8000/api/v1/update-fine/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "reason": "Speeding",
        //             "amount": 150.00,
        //             "issued_date": "2024-01-15",
        //             "due_date": "2024-02-15"
        //         }'

        Route::delete('/delete-fine/{fineId}', [VehicleSystemController::class, 'deleteFine']);
        // curl -X DELETE http://127.0.0.1:8000/api/v1/delete-fine/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"
        
        // ==================== ADVANCED QUERY OPERATIONS ====================
        Route::get('/get-vehicle-list-by-owner/{ownerId}', [VehicleSystemController::class, 'getVehicleListByOwner']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-vehicle-list-by-owner/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-vehicle-history-by-id/{vehicleId}', [VehicleSystemController::class, 'getVehicleHistoryById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-vehicle-history-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-vehicle-search-by-vin', [VehicleSystemController::class, 'getVehicleSearchByVin']);
        // curl -X GET "http://127.0.0.1:8000/api/v1/get-vehicle-search-by-vin?vin=1HGBH41JXMN109186" \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-owner-list-with-vehicle-counts', [VehicleSystemController::class, 'getOwnerListWithVehicleCounts']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-owner-list-with-vehicle-counts \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-vehicle-list-by-status/{status}', [VehicleSystemController::class, 'getVehicleListByStatus']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-vehicle-list-by-status/active \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-dashboard-stats-summary', [VehicleSystemController::class, 'getDashboardStatsSummary']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-dashboard-stats-summary \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        Route::get('/get-vehicle-compliance-score-by-id/{vehicleId}', [VehicleSystemController::class, 'getVehicleComplianceScoreById']);
        // curl -X GET http://127.0.0.1:8000/api/v1/get-vehicle-compliance-score-by-id/1 \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here"

        // Nested create endpoint for admin form
        Route::post('/vehicles', [TraMoController::class, 'createNested']);
        // curl -X POST http://127.0.0.1:8000/api/v1/vehicles \
        //     -H "Content-Type: application/json" \
        //     -H "Authorization: Bearer your-token-here" \
        //     -d '{
        //             "vehicle": {
        //                 "vin": "1HGBH41JXMN109186",
        //                 "plate_number": "ABC-1234",
        //                 "make": "Honda",
        //                 "model": "Civic",
        //                 "year": 2020,
        //                 "color": "Blue"
        //             },
        //             "owner": {
        //                 "first_name": "John",
        //                 "last_name": "Doe",
        //                 "email": "john.doe@example.com",
        //                 "phone": "1234567890"
        //             }
        //         }'
    });

    // Public plate search
    Route::get('/vehicle/search/{plate}', [TraMoController::class, 'searchByPlate']);
    // curl -X GET http://127.0.0.1:8000/api/v1/vehicle/search/ABC-1234 \
    //     -H "Content-Type: application/json"
});


