<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Check if admin is authenticated via session
        if (!session('admin_id') || !session('admin_token')) {
            return response()->json([
                'success' => false,
                'message' => 'Authentication required',
                'error' => 'Please login to access this resource'
            ], 401);
        }

        // Verify admin still exists and is active
        $admin = \App\Models\Admin::find(session('admin_id'));
        if (!$admin) {
            // Clear invalid session
            session()->forget(['admin_token', 'admin_id']);
            
            return response()->json([
                'success' => false,
                'message' => 'Invalid session',
                'error' => 'Admin account not found'
            ], 401);
        }

        // Add admin info to request for use in controllers
        $request->merge(['current_admin' => $admin]);

        return $next($request);
    }
}
