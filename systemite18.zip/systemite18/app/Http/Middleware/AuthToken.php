<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Admin;

class AuthToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Get token from Authorization header
        $token = $request->bearerToken();
        
        // If no bearer token, try to get from X-API-Token header
        if (!$token) {
            $token = $request->header('X-API-Token');
        }

        // Also try getting from Authorization header directly if bearerToken() didn't work
        if (!$token) {
            $authHeader = $request->header('Authorization');
            if ($authHeader && str_starts_with($authHeader, 'Bearer ')) {
                $token = substr($authHeader, 7);
            }
        }

        // Trim any whitespace
        if ($token) {
            $token = trim($token);
        }

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Authentication required',
                'error' => 'Please provide a valid API token'
            ], 401);
        }

        // Find admin by token (trim token for comparison)
        $admin = Admin::with('role')->where('api_token', $token)->first();
        
        if (!$admin) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid token',
                'error' => 'The provided token is invalid or expired. Please login again.'
            ], 401);
        }

        // Add admin info to request for use in controllers
        $request->merge(['current_admin' => $admin]);

        return $next($request);
    }
}
