<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Address;
use App\Models\Owner;
use App\Models\Vehicle;
use App\Models\Registration;
use App\Models\Insurance;
use App\Models\Fine;
use App\Models\Admin;

class TraMoController extends Controller
{
    public function createNested(Request $request)
    {
        $payload = $request->all();

        $rules = [
            'vehicle.vin' => 'required|string|max:50|unique:vehicles,vin|regex:/^[A-HJ-NPR-Z0-9]{17}$/',
            'vehicle.make' => 'required|string|max:50',
            'vehicle.model' => 'required|string|max:50',
            'vehicle.color' => 'required|string|max:50',
            'vehicle.year' => 'required|integer|min:1900|max:' . (date('Y') + 1),
            'vehicle.status' => 'nullable|string|in:Active,Inactive,Sold,Stolen',
            'vehicle.pin' => 'nullable|string|max:10',

            'owner.first_name' => 'required|string|max:100',
            'owner.last_name' => 'required|string|max:100',
            'owner.phone' => 'required|string|max:20',
            'owner.license_code' => 'required|string|max:50|unique:owners,LicenseNumber',

            'owner.address.street' => 'required|string|max:255',
            'owner.address.city' => 'required|string|max:100',
            'owner.address.province' => 'required|string|max:100',
            'owner.address.postal_code' => 'required|string|max:20',

            'registration.plate_number' => 'required|string|max:20',
            'registration.registration_number' => 'nullable|string|max:50',
            'registration.registration_date' => 'required|date',
            'registration.expiration_date' => 'required|date|after:registration.registration_date',
            'registration.status' => 'nullable|string|max:50',

            'insurance.provider' => 'nullable|string|max:50',
            'insurance.policy_number' => 'nullable|string|max:50',
            'insurance.coverage' => 'nullable|string',
            'insurance.start_date' => 'nullable|date',
            'insurance.end_date' => 'nullable|date|after:insurance.start_date',

            'fines' => 'nullable|array',
            'fines.*.amount' => 'required_with:fines|numeric|min:0',
            'fines.*.reason' => 'required_with:fines|string|max:100',
            'fines.*.issued_date' => 'required_with:fines|date',
            'fines.*.due_date' => 'required_with:fines|date|after_or_equal:fines.*.issued_date',
        ];

        $validator = Validator::make($payload, $rules);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        return DB::transaction(function () use ($payload) {
            $address = Address::create([
                'street' => $payload['owner']['address']['street'],
                'city' => $payload['owner']['address']['city'],
                'province' => $payload['owner']['address']['province'],
                'postal_code' => $payload['owner']['address']['postal_code'],
            ]);

            $owner = Owner::create([
                'FName' => $payload['owner']['first_name'],
                'LName' => $payload['owner']['last_name'],
                'address_id' => $address->address_id,
                'PhoneNumber' => $payload['owner']['phone'],
                'LicenseNumber' => $payload['owner']['license_code'],
            ]);

            $vehicle = Vehicle::create([
                'owner_id' => $owner->owner_id,
                'vin' => $payload['vehicle']['vin'],
                'make' => $payload['vehicle']['make'],
                'model' => $payload['vehicle']['model'],
                'color' => $payload['vehicle']['color'],
                'year' => $payload['vehicle']['year'],
                'vehicle_status' => $payload['vehicle']['status'] ?? 'Active',
                'pin' => $payload['vehicle']['pin'] ?? null,
            ]);

            Registration::create([
                'vehicle_id' => $vehicle->vehicle_id,
                'plate_number' => $payload['registration']['plate_number'],
                'registration_number' => $payload['registration']['registration_number'] ?? null,
                'registration_date' => $payload['registration']['registration_date'],
                'expiration_date' => $payload['registration']['expiration_date'],
                'status' => $payload['registration']['status'] ?? 'Active',
            ]);

            if (!empty($payload['insurance'])) {
                Insurance::create([
                    'vehicle_id' => $vehicle->vehicle_id,
                    'serial_number' => $payload['insurance']['serial_number'] ?? null,
                    'provider' => $payload['insurance']['provider'] ?? null,
                    'policy_number' => $payload['insurance']['policy_number'] ?? null,
                    'coverage' => $payload['insurance']['coverage'] ?? null,
                    'start_date' => $payload['insurance']['start_date'] ?? null,
                    'end_date' => $payload['insurance']['end_date'] ?? null,
                ]);
            }

            if (!empty($payload['fines']) && is_array($payload['fines'])) {
                foreach ($payload['fines'] as $fine) {
                    Fine::create([
                        'vehicle_id' => $vehicle->vehicle_id,
                        'serial_number' => $fine['serial_number'] ?? null,
                        'issued_date' => $fine['issued_date'],
                        'due_date' => $fine['due_date'],
                        'amount' => $fine['amount'],
                        'reason' => $fine['reason'],
                    ]);
                }
            }

            return response()->json([
                'success' => true,
                'data' => $vehicle->load(['owner', 'owner.address']),
                'message' => 'Vehicle and related data created successfully'
            ], 201);
        });
    }

    public function searchByPlate(Request $request, string $plate)
    {
        $pin = $request->query('pin');
        
        // Check if user is authenticated admin by validating token
        $isAdmin = false;
        $token = $request->bearerToken();
        if (!$token) {
            $token = $request->header('X-API-Token');
        }
        
        if ($token) {
            $admin = Admin::where('api_token', $token)->first();
            $isAdmin = $admin !== null;
        }
        
        $vehicle = Vehicle::query()
            ->select(['vehicles.*'])
            ->join('registrations', 'registrations.vehicle_id', '=', 'vehicles.vehicle_id')
            ->where('registrations.plate_number', $plate)
            ->with([
                'owner',
                'owner.address',
                'insurance' => function ($q) { $q->orderByDesc('end_date'); },
                'fines' => function ($q) { $q->orderByDesc('issued_date'); },
                'registrations' => function ($q) use ($plate) { $q->where('plate_number', $plate)->orderByDesc('registration_date'); },
            ])
            ->first();

        if (!$vehicle) {
            return response()->json([
                'success' => false,
                'data' => null,
                'message' => 'No record found',
            ]);
        }

        // For regular users (non-admin), require PIN
        if (!$isAdmin) {
            if (!$pin) {
                return response()->json([
                    'success' => false,
                    'data' => null,
                    'message' => 'PIN is required to access vehicle information',
                    'requires_pin' => true,
                ], 403);
            }

            // Verify PIN matches
            if ($vehicle->pin !== $pin) {
                return response()->json([
                    'success' => false,
                    'data' => null,
                    'message' => 'Invalid PIN. Access denied.',
                ], 403);
            }
        }

        return response()->json([
            'success' => true,
            'data' => $vehicle,
            'message' => 'Record found',
        ]);
    }
}
