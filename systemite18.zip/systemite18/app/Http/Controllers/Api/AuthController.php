<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\AdminRole;
use App\Models\AdminAction;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    /**
     * Admin Login
     * POST /api/v1/admin/login
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $admin = Admin::with('role')->where('username', $request->username)->first();

        if (!$admin || !Hash::check($request->password, $admin->password_hash)) {
            // Log failed login attempt
            AdminAction::create([
                'admin_id' => null,
                'action_type' => 'login_failed',
                'description' => 'Failed login attempt for username: ' . $request->username
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Invalid credentials'
            ], 401);
        }

        // Generate API token (simple implementation)
        $token = Str::random(60);
        
        // Store token in database for API authentication
        $admin->update(['api_token' => $token]);

        // Log successful login
        AdminAction::create([
            'admin_id' => $admin->admin_id,
            'action_type' => 'login_success',
            'description' => 'Admin logged in successfully'
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'admin' => [
                    'admin_id' => $admin->admin_id,
                    'username' => $admin->username,
                    'email' => $admin->email,
                    'role' => $admin->role
                ],
                'token' => $token
            ],
            'message' => 'Login successful'
        ], 200);
    }

    /**
     * Admin Logout
     * POST /api/v1/admin/logout
     */
    public function logout(Request $request)
    {
        // Get token from Authorization header
        $token = $request->bearerToken();
        
        // If no bearer token, try to get from X-API-Token header
        if (!$token) {
            $token = $request->header('X-API-Token');
        }

        if ($token) {
            // Find admin by token and clear it
            $admin = Admin::where('api_token', $token)->first();
            
            if ($admin) {
                // Clear API token
                $admin->update(['api_token' => null]);
                
                // Log logout action
                AdminAction::create([
                    'admin_id' => $admin->admin_id,
                    'action_type' => 'logout',
                    'description' => 'Admin logged out'
                ]);
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Logout successful'
        ], 200);
    }

    /**
     * Get Current Admin Profile
     * GET /api/v1/admin/profile
     */
    public function profile(Request $request)
    {
        $admin = $request->get('current_admin');
        
        if (!$admin) {
            return response()->json([
                'success' => false,
                'message' => 'Not authenticated'
            ], 401);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'admin_id' => $admin->admin_id,
                'username' => $admin->username,
                'email' => $admin->email,
                'role' => $admin->role,
                'created_at' => $admin->created_at
            ],
            'message' => 'Profile retrieved successfully'
        ], 200);
    }

    /**
     * Create New Admin (Super Admin Only)
     * POST /api/v1/admin/create
     */
    public function createAdmin(Request $request)
    {
        // Check if current admin has super admin role
        $currentAdmin = $request->get('current_admin');
        if (!$currentAdmin) {
            return response()->json([
                'success' => false,
                'message' => 'Not authenticated'
            ], 401);
        }

        if ($currentAdmin->role->role_level < 3) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient permissions'
            ], 403);
        }

        $validator = Validator::make($request->all(), [
            'username' => 'required|string|max:100|unique:admins,username',
            'email' => 'required|email|max:150|unique:admins,email',
            'password' => 'required|string|min:8|confirmed',
            'role_id' => 'required|exists:admin_roles,admin_role_id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $admin = Admin::create([
                'username' => $request->username,
                'email' => $request->email,
                'password_hash' => Hash::make($request->password),
                'role_id' => $request->role_id
            ]);

            // Log admin creation
            AdminAction::create([
                'admin_id' => $currentAdmin->admin_id,
                'action_type' => 'create_admin',
                'description' => 'Created new admin: ' . $admin->username
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'admin_id' => $admin->admin_id,
                    'username' => $admin->username,
                    'email' => $admin->email,
                    'role_id' => $admin->role_id
                ],
                'message' => 'Admin created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create admin',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get Admin Actions Log
     * GET /api/v1/admin/actions
     */
    public function getAdminActions(Request $request)
    {
        $currentAdmin = $request->get('current_admin');
        if (!$currentAdmin) {
            return response()->json([
                'success' => false,
                'message' => 'Not authenticated'
            ], 401);
        }

        if ($currentAdmin->role->role_level < 2) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient permissions'
            ], 403);
        }

        $actions = AdminAction::with('admin')
            ->orderByDesc('created_at')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $actions,
            'message' => 'Admin actions retrieved successfully'
        ], 200);
    }

    /**
     * Get All Admin Roles
     * GET /api/v1/admin/roles
     */
    public function getRoles(Request $request)
    {
        $roles = AdminRole::orderBy('role_level')->get();

        return response()->json([
            'success' => true,
            'data' => $roles,
            'message' => 'Admin roles retrieved successfully'
        ], 200);
    }
}
