<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Vehicle;
use App\Models\Owner;
use App\Models\Address;
use App\Models\Registration;
use App\Models\Insurance;
use App\Models\Fine;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Http\Requests\CreateVehicleRequest;
use App\Http\Requests\UpdateVehicleRequest;

class VehicleSystemController extends Controller
{
    // ==================== VEHICLE CRUD OPERATIONS ====================
    
    /**
     * Get Vehicle List with Owners
     * GET /api/v1/get-vehicle-list-with-owners
     */
    public function getVehicleListWithOwners(Request $request)
    {
        $vehicles = Vehicle::with(['owner'])
            ->select(['vehicle_id', 'owner_id', 'vin', 'make', 'model', 'color', 'year', 'vehicle_status'])
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $vehicles,
            'message' => 'Vehicles retrieved successfully'
        ], 200);
    }

    /**
     * Create New Vehicle
     * POST /api/v1/create-vehicle
     */
    public function createVehicle(CreateVehicleRequest $request)
    {
        try {
            $vehicle = Vehicle::create($request->validated());
            
            return response()->json([
                'success' => true,
                'data' => $vehicle->load('owner'),
                'message' => 'Vehicle created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create vehicle',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Vehicle
     * PUT /api/v1/update-vehicle/{vehicleId}
     */
    public function updateVehicle(UpdateVehicleRequest $request, $vehicleId)
    {
        $vehicle = Vehicle::find($vehicleId);
        
        if (!$vehicle) {
            return response()->json([
                'success' => false,
                'message' => 'Vehicle not found'
            ], 404);
        }

        try {
            $vehicle->update($request->validated());
            
            return response()->json([
                'success' => true,
                'data' => $vehicle->load('owner'),
                'message' => 'Vehicle updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update vehicle',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete Vehicle
     * DELETE /api/v1/delete-vehicle/{vehicleId}
     */
    public function deleteVehicle($vehicleId)
    {
        $vehicle = Vehicle::find($vehicleId);
        
        if (!$vehicle) {
            return response()->json([
                'success' => false,
                'message' => 'Vehicle not found'
            ], 404);
        }

        try {
            $vehicle->delete(); // Soft delete
            
            return response()->json([
                'success' => true,
                'message' => 'Vehicle deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete vehicle',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== OWNER CRUD OPERATIONS ====================
    
    /**
     * Get Owner List
     * GET /api/v1/get-owner-list
     */
    public function getOwnerList(Request $request)
    {
        $owners = Owner::with(['address'])
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $owners,
            'message' => 'Owners retrieved successfully'
        ], 200);
    }

    /**
     * Get Owner by ID
     * GET /api/v1/get-owner-by-id/{ownerId}
     */
    public function getOwnerById($ownerId)
    {
        $owner = Owner::with(['address', 'vehicles'])->find($ownerId);
        
        if (!$owner) {
            return response()->json([
                'success' => false,
                'message' => 'Owner not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $owner,
            'message' => 'Owner retrieved successfully'
        ], 200);
    }

    /**
     * Create New Owner
     * POST /api/v1/create-owner
     */
    public function createOwner(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'FName' => 'required|string|max:50',
            'LName' => 'required|string|max:50',
            'address_id' => 'required|exists:address,address_id',
            'PhoneNumber' => 'required|string|max:20',
            'LicenseNumber' => 'required|string|max:50|unique:owners,LicenseNumber'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $owner = Owner::create($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $owner->load('address'),
                'message' => 'Owner created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create owner',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Owner
     * PUT /api/v1/update-owner/{ownerId}
     */
    public function updateOwner(Request $request, $ownerId)
    {
        $owner = Owner::find($ownerId);
        
        if (!$owner) {
            return response()->json([
                'success' => false,
                'message' => 'Owner not found'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'FName' => 'sometimes|string|max:50',
            'LName' => 'sometimes|string|max:50',
            'address_id' => 'sometimes|exists:address,address_id',
            'PhoneNumber' => 'sometimes|string|max:20',
            'LicenseNumber' => ['sometimes', 'string', 'max:50', Rule::unique('owners', 'LicenseNumber')->ignore($ownerId, 'owner_id')],
            // Address fields
            'street' => 'sometimes|string|max:255',
            'city' => 'sometimes|string|max:100',
            'province' => 'sometimes|string|max:100',
            'postal_code' => 'sometimes|string|max:20',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Handle address update if address fields are provided
            if ($request->has('street') || $request->has('city') || $request->has('province') || $request->has('postal_code')) {
                $address = $owner->address;
                
                if ($address) {
                    // Update existing address
                    $address->update([
                        'street' => $request->get('street', $address->street),
                        'city' => $request->get('city', $address->city),
                        'province' => $request->get('province', $address->province),
                        'postal_code' => $request->get('postal_code', $address->postal_code),
                    ]);
                } else {
                    // Create new address if owner doesn't have one
                    $address = Address::create([
                        'street' => $request->get('street', ''),
                        'city' => $request->get('city', ''),
                        'province' => $request->get('province', ''),
                        'postal_code' => $request->get('postal_code', ''),
                    ]);
                    $owner->address_id = $address->address_id;
                    $owner->save();
                }
            }

            // Update owner fields (excluding address_id if address fields were provided)
            $ownerData = $request->only(['FName', 'LName', 'PhoneNumber', 'LicenseNumber']);
            if (!$request->has('street') && !$request->has('city') && !$request->has('province') && !$request->has('postal_code')) {
                // Only update address_id if address fields were not provided
                if ($request->has('address_id')) {
                    $ownerData['address_id'] = $request->get('address_id');
                }
            }
            
            if (!empty($ownerData)) {
                $owner->update($ownerData);
            }
            
            return response()->json([
                'success' => true,
                'data' => $owner->load('address'),
                'message' => 'Owner updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update owner',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete Owner
     * DELETE /api/v1/delete-owner/{ownerId}
     */
    public function deleteOwner($ownerId)
    {
        $owner = Owner::find($ownerId);
        
        if (!$owner) {
            return response()->json([
                'success' => false,
                'message' => 'Owner not found'
            ], 404);
        }

        try {
            $owner->delete(); // Soft delete
            
            return response()->json([
                'success' => true,
                'message' => 'Owner deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete owner',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== REGISTRATION CRUD OPERATIONS ====================
    
    /**
     * Get Registration List
     * GET /api/v1/get-registration-list
     */
    public function getRegistrationList(Request $request)
    {
        $registrations = Registration::with(['vehicle.owner'])
            ->orderByDesc('registration_date')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $registrations,
            'message' => 'Registrations retrieved successfully'
        ], 200);
    }

    /**
     * Get Registration by ID
     * GET /api/v1/get-registration-by-id/{registrationId}
     */
    public function getRegistrationById($registrationId)
    {
        $registration = Registration::with(['vehicle.owner'])->find($registrationId);
        
        if (!$registration) {
            return response()->json([
                'success' => false,
                'message' => 'Registration not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $registration,
            'message' => 'Registration retrieved successfully'
        ], 200);
    }
    
    /**
     * Create New Registration
     * POST /api/v1/create-registration
     */
    public function createRegistration(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'required|exists:vehicles,vehicle_id',
            'registration_date' => 'required|date',
            'expiration_date' => 'required|date|after:registration_date',
            'registration_number' => 'required|string|max:50|unique:registrations,registration_number'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $registration = Registration::create($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $registration->load(['vehicle.owner']),
                'message' => 'Registration created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create registration',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Registration
     * PUT /api/v1/update-registration/{registrationId}
     */
    public function updateRegistration(Request $request, $registrationId)
    {
        $registration = Registration::find($registrationId);
        
        if (!$registration) {
            return response()->json([
                'success' => false,
                'message' => 'Registration not found'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'sometimes|exists:vehicles,vehicle_id',
            'registration_date' => 'sometimes|date',
            'expiration_date' => 'sometimes|date|after:registration_date',
            'registration_number' => ['sometimes', 'string', 'max:50', Rule::unique('registrations', 'registration_number')->ignore($registrationId, 'registration_id')]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $registration->update($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $registration->load(['vehicle.owner']),
                'message' => 'Registration updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update registration',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete Registration
     * DELETE /api/v1/delete-registration/{registrationId}
     */
    public function deleteRegistration($registrationId)
    {
        $registration = Registration::find($registrationId);
        
        if (!$registration) {
            return response()->json([
                'success' => false,
                'message' => 'Registration not found'
            ], 404);
        }

        try {
            $registration->delete(); // Soft delete
            
            return response()->json([
                'success' => true,
                'message' => 'Registration deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete registration',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== INSURANCE CRUD OPERATIONS ====================
    
    /**
     * Get Insurance List
     * GET /api/v1/get-insurance-list
     */
    public function getInsuranceList(Request $request)
    {
        $insurance = Insurance::with(['vehicle.owner'])
            ->orderByDesc('start_date')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $insurance,
            'message' => 'Insurance policies retrieved successfully'
        ], 200);
    }

    /**
     * Get Insurance by ID
     * GET /api/v1/get-insurance-by-id/{insuranceId}
     */
    public function getInsuranceById($insuranceId)
    {
        $insurance = Insurance::with(['vehicle.owner'])->find($insuranceId);
        
        if (!$insurance) {
            return response()->json([
                'success' => false,
                'message' => 'Insurance policy not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $insurance,
            'message' => 'Insurance policy retrieved successfully'
        ], 200);
    }
    
    /**
     * Create New Insurance
     * POST /api/v1/create-insurance
     */
    public function createInsurance(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'required|exists:vehicles,vehicle_id',
            'policy_number' => 'required|string|max:50|unique:insurance,policy_number',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'coverage' => 'nullable|string',
            'provider' => 'required|string|max:50'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $insurance = Insurance::create($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $insurance->load(['vehicle.owner']),
                'message' => 'Insurance created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create insurance',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Insurance
     * PUT /api/v1/update-insurance/{insuranceId}
     */
    public function updateInsurance(Request $request, $insuranceId)
    {
        $insurance = Insurance::find($insuranceId);
        
        if (!$insurance) {
            return response()->json([
                'success' => false,
                'message' => 'Insurance policy not found'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'sometimes|exists:vehicles,vehicle_id',
            'policy_number' => ['sometimes', 'string', 'max:50', Rule::unique('insurance', 'policy_number')->ignore($insuranceId, 'insurance_id')],
            'start_date' => 'sometimes|date',
            'end_date' => 'sometimes|date|after:start_date',
            'coverage' => 'sometimes|nullable|string',
            'provider' => 'sometimes|string|max:50'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $insurance->update($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $insurance->load(['vehicle.owner']),
                'message' => 'Insurance policy updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update insurance policy',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete Insurance
     * DELETE /api/v1/delete-insurance/{insuranceId}
     */
    public function deleteInsurance($insuranceId)
    {
        $insurance = Insurance::find($insuranceId);
        
        if (!$insurance) {
            return response()->json([
                'success' => false,
                'message' => 'Insurance policy not found'
            ], 404);
        }

        try {
            $insurance->delete(); // Soft delete
            
            return response()->json([
                'success' => true,
                'message' => 'Insurance policy deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete insurance policy',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== FINE CRUD OPERATIONS ====================
    
    /**
     * Get Fine List
     * GET /api/v1/get-fine-list
     */
    public function getFineList(Request $request)
    {
        $fines = Fine::with(['vehicle.owner'])
            ->orderByDesc('issued_date')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $fines,
            'message' => 'Fines retrieved successfully'
        ], 200);
    }

    /**
     * Get Fine by ID
     * GET /api/v1/get-fine-by-id/{fineId}
     */
    public function getFineById($fineId)
    {
        $fine = Fine::with(['vehicle.owner'])->find($fineId);
        
        if (!$fine) {
            return response()->json([
                'success' => false,
                'message' => 'Fine not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $fine,
            'message' => 'Fine retrieved successfully'
        ], 200);
    }
    
    /**
     * Create New Fine
     * POST /api/v1/create-fine
     */
    public function createFine(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'required|exists:vehicles,vehicle_id',
            'amount' => 'required|numeric|min:0',
            'issued_date' => 'required|date',
            'due_date' => 'required|date|after:issued_date',
            'reason' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $fine = Fine::create($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $fine->load(['vehicle.owner']),
                'message' => 'Fine created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create fine',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Fine
     * PUT /api/v1/update-fine/{fineId}
     */
    public function updateFine(Request $request, $fineId)
    {
        $fine = Fine::find($fineId);
        
        if (!$fine) {
            return response()->json([
                'success' => false,
                'message' => 'Fine not found'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'sometimes|exists:vehicles,vehicle_id',
            'amount' => 'sometimes|numeric|min:0',
            'issued_date' => 'sometimes|date',
            'due_date' => 'sometimes|date|after:issued_date',
            'reason' => 'sometimes|string|max:100'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $fine->update($request->all());
            
            return response()->json([
                'success' => true,
                'data' => $fine->load(['vehicle.owner']),
                'message' => 'Fine updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update fine',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete Fine
     * DELETE /api/v1/delete-fine/{fineId}
     */
    public function deleteFine($fineId)
    {
        $fine = Fine::find($fineId);
        
        if (!$fine) {
            return response()->json([
                'success' => false,
                'message' => 'Fine not found'
            ], 404);
        }

        try {
            $fine->delete(); // Soft delete
            
            return response()->json([
                'success' => true,
                'message' => 'Fine deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete fine',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== EXISTING READ OPERATIONS (Enhanced) ====================
    
    /**
     * Get Registration List Expiring Soon
     * GET /api/v1/get-registration-list-expiring-soon
     */
    public function getRegistrationListExpiringSoon(Request $request)
    {
        $days = (int) $request->get('days', 30);
        $until = Carbon::now()->addDays($days)->toDateString();

        $registrations = Registration::with(['vehicle.owner'])
            ->whereDate('expiration_date', '<=', $until)
            ->whereDate('expiration_date', '>=', Carbon::now()->toDateString())
            ->orderBy('expiration_date')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $registrations,
            'message' => 'Expiring registrations retrieved successfully'
        ], 200);
    }

    /**
     * Get Fine List Overdue
     * GET /api/v1/get-fine-list-overdue
     */
    public function getFineListOverdue(Request $request)
    {
        $today = Carbon::now()->toDateString();
        $fines = Fine::with(['vehicle.owner'])
            ->whereDate('due_date', '<', $today)
            ->orderBy('due_date')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $fines,
            'message' => 'Overdue fines retrieved successfully'
        ], 200);
    }

    /**
     * Get Insurance List Expiring Soon
     * GET /api/v1/get-insurance-list-expiring-soon
     */
    public function getInsuranceListExpiringSoon(Request $request)
    {
        $days = (int) $request->get('days', 30);
        $until = Carbon::now()->addDays($days)->toDateString();

        $policies = Insurance::with(['vehicle.owner'])
            ->whereDate('end_date', '<=', $until)
            ->whereDate('end_date', '>=', Carbon::now()->toDateString())
            ->orderBy('end_date')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $policies,
            'message' => 'Expiring insurance policies retrieved successfully'
        ], 200);
    }

    /**
     * Get Vehicle List by Owner
     * GET /api/v1/get-vehicle-list-by-owner/{ownerId}
     */
    public function getVehicleListByOwner(Request $request, int $ownerId)
    {
        $owner = Owner::find($ownerId);
        
        if (!$owner) {
            return response()->json([
                'success' => false,
                'message' => 'Owner not found'
            ], 404);
        }

        $vehicles = Vehicle::where('owner_id', $owner->owner_id)
            ->select(['vehicle_id', 'owner_id', 'vin', 'make', 'model', 'color', 'year', 'vehicle_status'])
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => [
            'owner' => $owner,
            'vehicles' => $vehicles,
            ],
            'message' => 'Owner vehicles retrieved successfully'
        ], 200);
    }

    /**
     * Get Vehicle History by ID
     * GET /api/v1/get-vehicle-history-by-id/{vehicleId}
     */
    public function getVehicleHistoryById(Request $request, int $vehicleId)
    {
        $vehicle = Vehicle::with(['owner'])->find($vehicleId);
        
        if (!$vehicle) {
            return response()->json([
                'success' => false,
                'message' => 'Vehicle not found'
            ], 404);
        }

        $registrations = Registration::where('vehicle_id', $vehicleId)->orderByDesc('registration_date')->get();
        $insurance = Insurance::where('vehicle_id', $vehicleId)->orderByDesc('start_date')->get();
        $fines = Fine::where('vehicle_id', $vehicleId)->orderByDesc('issued_date')->get();

        return response()->json([
            'success' => true,
            'data' => [
            'vehicle' => $vehicle,
            'registrations' => $registrations,
            'insurance' => $insurance,
            'fines' => $fines,
            ],
            'message' => 'Vehicle history retrieved successfully'
        ], 200);
    }

    /**
     * Get Vehicle Search by VIN
     * GET /api/v1/get-vehicle-search-by-vin
     */
    public function getVehicleSearchByVin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vin' => 'required|string|min:3|max:50'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $vin = $request->get('vin');
        $vehicles = Vehicle::with(['owner', 'registrations'])
            ->where('vin', 'like', "%$vin%")
            ->get();

        return response()->json([
            'success' => true,
            'data' => $vehicles,
            'message' => 'Vehicle search completed successfully'
        ], 200);
    }

    /**
     * Get Owner List with Vehicle Counts
     * GET /api/v1/get-owner-list-with-vehicle-counts
     */
    public function getOwnerListWithVehicleCounts(Request $request)
    {
        $owners = Owner::withCount('vehicles')
            ->orderByDesc('vehicles_count')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $owners,
            'message' => 'Owners with vehicle counts retrieved successfully'
        ], 200);
    }

    /**
     * Get Vehicle List by Status
     * GET /api/v1/get-vehicle-list-by-status/{status}
     */
    public function getVehicleListByStatus(Request $request, string $status)
    {
        $validStatuses = ['Active', 'Inactive', 'Sold', 'Stolen'];
        
        if (!in_array($status, $validStatuses)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid vehicle status. Valid statuses: ' . implode(', ', $validStatuses)
            ], 422);
        }

        $vehicles = Vehicle::where('vehicle_status', $status)
            ->with(['owner'])
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $vehicles,
            'message' => 'Vehicles by status retrieved successfully'
        ], 200);
    }

    /**
     * Get Dashboard Stats Summary
     * GET /api/v1/get-dashboard-stats-summary
     */
    public function getDashboardStatsSummary(Request $request)
    {
        $totalVehicles = Vehicle::count();
        $totalOwners = Owner::count();

        $expiringRegistrations = Registration::whereDate('expiration_date', '<=', Carbon::now()->addDays(30)->toDateString())
            ->whereDate('expiration_date', '>=', Carbon::now()->toDateString())
            ->count();

        $overdueFines = Fine::whereDate('due_date', '<', Carbon::now()->toDateString())->count();
        $expiringInsurance = Insurance::whereDate('end_date', '<=', Carbon::now()->addDays(30)->toDateString())
            ->whereDate('end_date', '>=', Carbon::now()->toDateString())
            ->count();

        return response()->json([
            'success' => true,
            'data' => [
            'totalVehicles' => $totalVehicles,
            'totalOwners' => $totalOwners,
            'expiringRegistrations30d' => $expiringRegistrations,
            'overdueFines' => $overdueFines,
            'expiringInsurance30d' => $expiringInsurance,
            ],
            'message' => 'Dashboard stats retrieved successfully'
        ], 200);
    }

    /**
     * Get Vehicle Compliance Score by ID
     * GET /api/v1/get-vehicle-compliance-score-by-id/{vehicleId}
     */
    public function getVehicleComplianceScoreById(Request $request, int $vehicleId)
    {
        $vehicle = Vehicle::with(['owner'])->find($vehicleId);
        
        if (!$vehicle) {
            return response()->json([
                'success' => false,
                'message' => 'Vehicle not found'
            ], 404);
        }

        $now = Carbon::now()->toDateString();

        $latestRegistration = Registration::where('vehicle_id', $vehicleId)
            ->orderByDesc('expiration_date')
            ->first();
        $registrationValid = $latestRegistration && $latestRegistration->expiration_date >= $now;

        $latestInsurance = Insurance::where('vehicle_id', $vehicleId)
            ->orderByDesc('end_date')
            ->first();
        $insuranceValid = $latestInsurance && $latestInsurance->end_date >= $now;

        $overdueFinesCount = Fine::where('vehicle_id', $vehicleId)
            ->whereDate('due_date', '<', $now)
            ->count();

        $score = 0;
        $breakdown = [
            'registration' => $registrationValid ? 40 : 0,
            'insurance' => $insuranceValid ? 40 : 0,
            'fines' => $overdueFinesCount === 0 ? 20 : 0,
        ];
        $score = array_sum($breakdown);

        return response()->json([
            'success' => true,
            'data' => [
            'vehicle' => [
                'vehicle_id' => $vehicle->vehicle_id,
                'vin' => $vehicle->vin,
                'make' => $vehicle->make,
                'model' => $vehicle->model,
                'owner' => $vehicle->owner,
            ],
            'score' => $score,
            'breakdown' => $breakdown,
            'details' => [
                'latestRegistration' => $latestRegistration,
                'latestInsurance' => $latestInsurance,
                'overdueFinesCount' => $overdueFinesCount,
            ],
            ],
            'message' => 'Vehicle compliance score retrieved successfully'
        ], 200);
    }
}