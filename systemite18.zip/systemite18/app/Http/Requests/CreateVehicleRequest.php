<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateVehicleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true; // For now, allow all requests. In production, implement proper authorization
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'owner_id' => 'required|exists:owners,owner_id',
            'vin' => 'required|string|max:50|unique:vehicles,vin|regex:/^[A-HJ-NPR-Z0-9]{17}$/',
            'make' => 'required|string|max:50|alpha_dash',
            'model' => 'required|string|max:50|alpha_dash',
            'color' => 'required|string|max:50|alpha',
            'year' => 'required|integer|min:1900|max:' . (date('Y') + 1),
            'vehicle_status' => 'required|string|in:Active,Inactive,Sold,Stolen'
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'vin.regex' => 'The VIN must be a valid 17-character VIN format.',
            'make.alpha_dash' => 'The make field may only contain letters, numbers, dashes and underscores.',
            'model.alpha_dash' => 'The model field may only contain letters, numbers, dashes and underscores.',
            'color.alpha' => 'The color field may only contain letters.',
            'vehicle_status.in' => 'The vehicle status must be one of: Active, Inactive, Sold, Stolen.'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'owner_id' => 'owner',
            'vin' => 'VIN',
            'make' => 'vehicle make',
            'model' => 'vehicle model',
            'color' => 'vehicle color',
            'year' => 'vehicle year',
            'vehicle_status' => 'vehicle status'
        ];
    }
}
