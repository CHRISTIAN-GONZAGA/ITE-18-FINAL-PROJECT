<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateVehicleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true; // For now, allow all requests. In production, implement proper authorization
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $vehicleId = $this->route('vehicleId');
        
        return [
            'owner_id' => 'sometimes|exists:owners,owner_id',
            'vin' => [
                'sometimes', 
                'string', 
                'max:50', 
                'regex:/^[A-HJ-NPR-Z0-9]{17}$/',
                Rule::unique('vehicles', 'vin')->ignore($vehicleId, 'vehicle_id')
            ],
            'make' => 'sometimes|string|max:50|alpha_dash',
            'model' => 'sometimes|string|max:50|alpha_dash',
            'color' => 'sometimes|string|max:50|alpha',
            'year' => 'sometimes|integer|min:1900|max:' . (date('Y') + 1),
            'vehicle_status' => 'sometimes|string|in:Active,Inactive,Sold,Stolen',
            'pin' => 'sometimes|nullable|string|max:10|regex:/^[0-9]{0,10}$/'
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'vin.regex' => 'The VIN must be a valid 17-character VIN format.',
            'vin.unique' => 'This VIN is already registered to another vehicle.',
            'make.alpha_dash' => 'The make field may only contain letters, numbers, dashes and underscores.',
            'model.alpha_dash' => 'The model field may only contain letters, numbers, dashes and underscores.',
            'color.alpha' => 'The color field may only contain letters.',
            'vehicle_status.in' => 'The vehicle status must be one of: Active, Inactive, Sold, Stolen.'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'owner_id' => 'owner',
            'vin' => 'VIN',
            'make' => 'vehicle make',
            'model' => 'vehicle model',
            'color' => 'vehicle color',
            'year' => 'vehicle year',
            'vehicle_status' => 'vehicle status'
        ];
    }
}
