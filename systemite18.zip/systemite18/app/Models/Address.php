<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    use HasFactory;

    protected $table = 'address';
    protected $primaryKey = 'address_id';
    public $timestamps = true;

    protected $fillable = [
        'street',
        'city',
        'province',
        'postal_code',
        'created_at',
        'created_by',
        'deleted_at',
        'deleted_by',
        'updated_at',
        'updated_by',
    ];

    public function owners()
    {
        return $this->hasMany(Owner::class, 'address_id');
    }
}
