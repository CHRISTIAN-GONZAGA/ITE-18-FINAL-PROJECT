<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminAction extends Model
{
    use HasFactory;

    protected $table = 'admin_actions';
    protected $primaryKey = 'action_id';
    public $timestamps = true;

    protected $fillable = [
        'admin_id',
        'action_type',
        'description',
    ];

    public function admin()
    {
        return $this->belongsTo(Admin::class, 'admin_id', 'admin_id');
    }
}
