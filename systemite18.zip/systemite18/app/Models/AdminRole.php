<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminRole extends Model
{
    use HasFactory;

    protected $table = 'admin_roles';
    protected $primaryKey = 'admin_role_id';
    public $timestamps = true;

    protected $fillable = [
        'role_name',
        'role_level',
        'permissions',
    ];

    public function admins()
    {
        return $this->hasMany(Admin::class, 'role_id', 'admin_role_id');
    }
}
