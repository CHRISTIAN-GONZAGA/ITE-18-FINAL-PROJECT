<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vehicle extends Model
{
    use HasFactory;

    protected $primaryKey = 'vehicle_id';

    protected $fillable = [
        'owner_id',
        'vin',
        'make',
        'model',
        'color',
        'year',
        'vehicle_status',
        'pin',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'deleted_at',
        'deleted_by'
    ];

    public function owner()
    {
        return $this->belongsTo(Owner::class, 'owner_id');
    }

    public function fines()
    {
        return $this->hasMany(Fine::class, 'vehicle_id');
    }

    public function insurance()
    {
        return $this->hasMany(Insurance::class, 'vehicle_id');
    }

    public function registrations()
    {
        return $this->hasMany(Registration::class, 'vehicle_id');
    }
}
