<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Admin extends Model
{
    use HasFactory, SoftDeletes;

    protected $primaryKey = 'admin_id';

    protected $fillable = [
        'username',
        'password_hash',
        'email',
        'role_id',
        'api_token',
    ];

    public function role()
    {
        return $this->belongsTo(AdminRole::class, 'role_id', 'admin_role_id');
    }

    public function actions()
    {
        return $this->hasMany(AdminAction::class, 'admin_id', 'admin_id');
    }
}
