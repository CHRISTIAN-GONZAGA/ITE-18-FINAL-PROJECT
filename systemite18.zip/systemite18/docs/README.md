# Website Access Guide

## Local access via XAMPP (Windows)
- Ensure PHP 3e= 8.2 (XAMPP 8.2/8.3) is installed.
- Place this project at `C:\xampp\htdocs\systemite18`.
- Start Apache (and MySQL if your app uses a database) from the XAMPP Control Panel.
- Open your browser and visit:
  - `http://localhost/systemite18/public`
  - If you configured a virtual host, use your host name (e.g. `http://systemite18.local`).

## Alternative: Laravel built-in server
- From the project root, run:
  - `composer install`
  - Copy `.env.example` to `.env` and update settings
  - `php artisan key:generate`
  - Start the dev server: `php artisan serve`
- Access at: `http://127.0.0.1:8000`

## API endpoints
- Base URL when served by Apache: `http://localhost/systemite18/public/api`
- Base URL when using `php artisan serve`: `http://127.0.0.1:8000/api`

## Authentication / credentials
- Login page (if enabled): `/login`
- Default/test credentials: update this section with your actual seeded users.
  - Example placeholder: `admin@example.com` / `password`

## Common issues
- If Composer reports a PHP version error, ensure your terminal uses the XAMPP PHP (check with `php -v` and `where php`).
- If visiting without `/public` shows a directory listing or 403, ensure your web root points to the `public/` directory or continue accessing via `/public`.
