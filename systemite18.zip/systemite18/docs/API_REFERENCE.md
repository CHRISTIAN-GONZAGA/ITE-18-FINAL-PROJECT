# Vehicle Management System API Documentation

## Overview
This API provides comprehensive CRUD operations for managing vehicles, owners, registrations, insurance policies, and fines in a vehicle management system.

**Base URL:** `http://127.0.0.1:8000/api/v1`

## Authentication
Currently, the API operates without authentication. For production use, implement Laravel Sanctum or Passport for API authentication.

## Response Format
All API responses follow this standard format:
```json
{
    "success": true|false,
    "data": {...},
    "message": "Description of the operation",
    "errors": {...} // Only present when success is false
}
```

## HTTP Status Codes
- `200` - Success
- `201` - Created successfully
- `404` - Resource not found
- `422` - Validation failed
- `500` - Server error

## API Endpoints Summary
**Total Endpoints:** 34
- **Vehicle Management:** 4 endpoints (Full CRUD)
- **Owner Management:** 5 endpoints (Full CRUD)
- **Registration Management:** 6 endpoints (Full CRUD)
- **Insurance Management:** 6 endpoints (Full CRUD)
- **Fine Management:** 6 endpoints (Full CRUD)
- **Advanced Queries:** 7 endpoints

---

## 1. Vehicle Management (Full CRUD)

### 1.1 Get Vehicle List with Owners
**GET** `/get-vehicle-list-with-owners`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "vehicle_id": 1,
                "owner_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic",
                "color": "Blue",
                "year": 2020,
                "vehicle_status": "Active",
                "owner": {
                    "owner_id": 1,
                    "FName": "John",
                    "LName": "Doe"
                }
            }
        ],
        "per_page": 15,
        "total": 200
    },
    "message": "Vehicles retrieved successfully"
}
```

### 1.2 Create Vehicle
**POST** `/create-vehicle`

**Request Body:**
```json
{
    "owner_id": 1,
    "vin": "1HGBH41JXMN109186",
    "make": "Honda",
    "model": "Civic",
    "color": "Blue",
    "year": 2020,
    "vehicle_status": "Active"
}
```

**Validation Rules:**
- `owner_id`: Required, must exist in owners table
- `vin`: Required, unique, max 50 characters
- `make`: Required, max 50 characters
- `model`: Required, max 50 characters
- `color`: Required, max 50 characters
- `year`: Required, integer between 1900 and current year + 1
- `vehicle_status`: Required, must be one of: Active, Inactive, Sold, Stolen

**Response Example:**
```json
{
    "success": true,
    "data": {
        "vehicle_id": 201,
        "owner_id": 1,
        "vin": "1HGBH41JXMN109186",
        "make": "Honda",
        "model": "Civic",
        "color": "Blue",
        "year": 2020,
        "vehicle_status": "Active",
        "owner": {
            "owner_id": 1,
            "FName": "John",
            "LName": "Doe"
        }
    },
    "message": "Vehicle created successfully"
}
```

### 1.3 Update Vehicle
**PUT** `/update-vehicle/{vehicleId}`

**Request Body:** (All fields optional)
```json
{
    "make": "Toyota",
    "model": "Camry",
    "vehicle_status": "Inactive"
}
```

**Response Example:**
```json
{
    "success": true,
    "data": {
        "vehicle_id": 1,
        "owner_id": 1,
        "vin": "1HGBH41JXMN109186",
        "make": "Toyota",
        "model": "Camry",
        "color": "Blue",
        "year": 2020,
        "vehicle_status": "Inactive",
        "owner": {
            "owner_id": 1,
            "FName": "John",
            "LName": "Doe"
        }
    },
    "message": "Vehicle updated successfully"
}
```

### 1.4 Delete Vehicle
**DELETE** `/delete-vehicle/{vehicleId}`

**Response Example:**
```json
{
    "success": true,
    "message": "Vehicle deleted successfully"
}
```

---

## 2. Owner Management (Full CRUD)

### 2.1 Get Owner List
**GET** `/get-owner-list`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe",
                "address_id": 1,
                "PhoneNumber": "+1234567890",
                "LicenseNumber": "DL123456789",
                "address": {
                    "address_id": 1,
                    "street": "123 Main St",
                    "city": "Anytown",
                    "state": "CA",
                    "zip_code": "12345"
                }
            }
        ],
        "per_page": 15,
        "total": 250
    },
    "message": "Owners retrieved successfully"
}
```

### 2.2 Get Owner by ID
**GET** `/get-owner-by-id/{ownerId}`

**Path Parameters:**
- `ownerId`: Required, owner ID

**Response Example:**
```json
{
    "success": true,
    "data": {
        "owner_id": 1,
        "FName": "John",
        "LName": "Doe",
        "address_id": 1,
        "PhoneNumber": "+1234567890",
        "LicenseNumber": "DL123456789",
        "address": {
            "address_id": 1,
            "street": "123 Main St",
            "city": "Anytown",
            "state": "CA",
            "zip_code": "12345"
        },
        "vehicles": [
            {
                "vehicle_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic"
            }
        ]
    },
    "message": "Owner retrieved successfully"
}
```

### 2.3 Create Owner
**POST** `/create-owner`

**Request Body:**
```json
{
    "FName": "Jane",
    "LName": "Smith",
    "address_id": 1,
    "PhoneNumber": "+1234567890",
    "LicenseNumber": "DL123456789"
}
```

**Validation Rules:**
- `FName`: Required, max 50 characters
- `LName`: Required, max 50 characters
- `address_id`: Required, must exist in addresses table
- `PhoneNumber`: Required, max 20 characters
- `LicenseNumber`: Required, unique, max 50 characters

**Response Example:**
```json
{
    "success": true,
    "data": {
        "owner_id": 251,
        "FName": "Jane",
        "LName": "Smith",
        "address_id": 1,
        "PhoneNumber": "+1234567890",
        "LicenseNumber": "DL123456789",
        "address": {
            "address_id": 1,
            "street": "123 Main St",
            "city": "Anytown",
            "state": "CA",
            "zip_code": "12345"
        }
    },
    "message": "Owner created successfully"
}
```

### 2.4 Update Owner
**PUT** `/update-owner/{ownerId}`

**Request Body:** (All fields optional)
```json
{
    "FName": "Jane",
    "LName": "Johnson",
    "PhoneNumber": "+1987654321"
}
```

**Response Example:**
```json
{
    "success": true,
    "data": {
        "owner_id": 1,
        "FName": "Jane",
        "LName": "Johnson",
        "address_id": 1,
        "PhoneNumber": "+1987654321",
        "LicenseNumber": "DL123456789",
        "address": {
            "address_id": 1,
            "street": "123 Main St",
            "city": "Anytown",
            "state": "CA",
            "zip_code": "12345"
        }
    },
    "message": "Owner updated successfully"
}
```

### 2.5 Delete Owner
**DELETE** `/delete-owner/{ownerId}`

**Response Example:**
```json
{
    "success": true,
    "message": "Owner deleted successfully"
}
```

---

## 3. Registration Management (Full CRUD)

### 3.1 Get Registration List
**GET** `/get-registration-list`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "registration_id": 1,
                "vehicle_id": 1,
                "registration_date": "2023-01-15",
                "expiration_date": "2024-01-15",
                "registration_number": "REG123456",
                "vehicle": {
                    "vehicle_id": 1,
                    "vin": "1HGBH41JXMN109186",
                    "make": "Honda",
                    "model": "Civic",
                    "owner": {
                        "owner_id": 1,
                        "FName": "John",
                        "LName": "Doe"
                    }
                }
            }
        ],
        "per_page": 15,
        "total": 200
    },
    "message": "Registrations retrieved successfully"
}
```

### 3.2 Get Registration by ID
**GET** `/get-registration-by-id/{registrationId}`

**Path Parameters:**
- `registrationId`: Required, registration ID

**Response Example:**
```json
{
    "success": true,
    "data": {
        "registration_id": 1,
        "vehicle_id": 1,
        "registration_date": "2023-01-15",
        "expiration_date": "2024-01-15",
        "registration_number": "REG123456",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Registration retrieved successfully"
}
```

### 3.3 Get Registration List Expiring Soon
**GET** `/get-registration-list-expiring-soon`

**Query Parameters:**
- `days` (optional): Number of days to look ahead (default: 30)

**Response Example:**
```json
{
    "success": true,
    "data": [
        {
            "registration_id": 1,
            "vehicle_id": 1,
            "registration_date": "2023-01-15",
            "expiration_date": "2024-01-15",
            "registration_number": "REG123456",
            "vehicle": {
                "vehicle_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic",
                "owner": {
                    "owner_id": 1,
                    "FName": "John",
                    "LName": "Doe"
                }
            }
        }
    ],
    "message": "Expiring registrations retrieved successfully"
}
```

### 3.2 Create Registration
**POST** `/create-registration`

**Request Body:**
```json
{
    "vehicle_id": 1,
    "registration_date": "2024-01-15",
    "expiration_date": "2025-01-15",
    "registration_number": "REG789012"
}
```

**Validation Rules:**
- `vehicle_id`: Required, must exist in vehicles table
- `registration_date`: Required, valid date
- `expiration_date`: Required, must be after registration_date
- `registration_number`: Required, unique, max 50 characters

**Response Example:**
```json
{
    "success": true,
    "data": {
        "registration_id": 201,
        "vehicle_id": 1,
        "registration_date": "2024-01-15",
        "expiration_date": "2025-01-15",
        "registration_number": "REG789012",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Registration created successfully"
}
```

### 3.5 Update Registration
**PUT** `/update-registration/{registrationId}`

**Request Body:** (All fields optional)
```json
{
    "expiration_date": "2025-01-15",
    "registration_number": "REG789012"
}
```

**Response Example:**
```json
{
    "success": true,
    "data": {
        "registration_id": 1,
        "vehicle_id": 1,
        "registration_date": "2023-01-15",
        "expiration_date": "2025-01-15",
        "registration_number": "REG789012",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Registration updated successfully"
}
```

### 3.6 Delete Registration
**DELETE** `/delete-registration/{registrationId}`

**Response Example:**
```json
{
    "success": true,
    "message": "Registration deleted successfully"
}
```

---

## 4. Insurance Management (Full CRUD)

### 4.1 Get Insurance List
**GET** `/get-insurance-list`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "insurance_id": 1,
                "vehicle_id": 1,
                "policy_number": "POL123456",
                "start_date": "2023-01-01",
                "end_date": "2024-01-01",
                "coverage_amount": 50000.00,
                "vehicle": {
                    "vehicle_id": 1,
                    "vin": "1HGBH41JXMN109186",
                    "make": "Honda",
                    "model": "Civic",
                    "owner": {
                        "owner_id": 1,
                        "FName": "John",
                        "LName": "Doe"
                    }
                }
            }
        ],
        "per_page": 15,
        "total": 150
    },
    "message": "Insurance policies retrieved successfully"
}
```

### 4.2 Get Insurance by ID
**GET** `/get-insurance-by-id/{insuranceId}`

**Path Parameters:**
- `insuranceId`: Required, insurance ID

**Response Example:**
```json
{
    "success": true,
    "data": {
        "insurance_id": 1,
        "vehicle_id": 1,
        "policy_number": "POL123456",
        "start_date": "2023-01-01",
        "end_date": "2024-01-01",
        "coverage_amount": 50000.00,
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Insurance policy retrieved successfully"
}
```

### 4.3 Get Insurance List Expiring Soon
**GET** `/get-insurance-list-expiring-soon`

**Query Parameters:**
- `days` (optional): Number of days to look ahead (default: 30)

**Response Example:**
```json
{
    "success": true,
    "data": [
        {
            "insurance_id": 1,
            "vehicle_id": 1,
            "policy_number": "POL123456",
            "start_date": "2023-01-01",
            "end_date": "2024-01-01",
            "coverage_amount": 50000.00,
            "vehicle": {
                "vehicle_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic",
                "owner": {
                    "owner_id": 1,
                    "FName": "John",
                    "LName": "Doe"
                }
            }
        }
    ],
    "message": "Expiring insurance policies retrieved successfully"
}
```

### 4.2 Create Insurance
**POST** `/create-insurance`

**Request Body:**
```json
{
    "vehicle_id": 1,
    "policy_number": "POL789012",
    "start_date": "2024-01-01",
    "end_date": "2025-01-01",
    "coverage_amount": 75000.00
}
```

**Validation Rules:**
- `vehicle_id`: Required, must exist in vehicles table
- `policy_number`: Required, unique, max 50 characters
- `start_date`: Required, valid date
- `end_date`: Required, must be after start_date
- `coverage_amount`: Required, numeric, minimum 0

**Response Example:**
```json
{
    "success": true,
    "data": {
        "insurance_id": 201,
        "vehicle_id": 1,
        "policy_number": "POL789012",
        "start_date": "2024-01-01",
        "end_date": "2025-01-01",
        "coverage_amount": 75000.00,
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Insurance created successfully"
}
```

### 4.5 Update Insurance
**PUT** `/update-insurance/{insuranceId}`

**Request Body:** (All fields optional)
```json
{
    "end_date": "2025-01-01",
    "coverage_amount": 75000.00
}
```

**Response Example:**
```json
{
    "success": true,
    "data": {
        "insurance_id": 1,
        "vehicle_id": 1,
        "policy_number": "POL123456",
        "start_date": "2023-01-01",
        "end_date": "2025-01-01",
        "coverage_amount": 75000.00,
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Insurance policy updated successfully"
}
```

### 4.6 Delete Insurance
**DELETE** `/delete-insurance/{insuranceId}`

**Response Example:**
```json
{
    "success": true,
    "message": "Insurance policy deleted successfully"
}
```

---

## 5. Fine Management (Full CRUD)

### 5.1 Get Fine List
**GET** `/get-fine-list`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "fine_id": 1,
                "vehicle_id": 1,
                "fine_amount": 150.00,
                "issued_date": "2024-01-01",
                "due_date": "2024-01-15",
                "violation_type": "Speeding",
                "description": "Exceeded speed limit by 15 mph",
                "vehicle": {
                    "vehicle_id": 1,
                    "vin": "1HGBH41JXMN109186",
                    "make": "Honda",
                    "model": "Civic",
                    "owner": {
                        "owner_id": 1,
                        "FName": "John",
                        "LName": "Doe"
                    }
                }
            }
        ],
        "per_page": 15,
        "total": 100
    },
    "message": "Fines retrieved successfully"
}
```

### 5.2 Get Fine by ID
**GET** `/get-fine-by-id/{fineId}`

**Path Parameters:**
- `fineId`: Required, fine ID

**Response Example:**
```json
{
    "success": true,
    "data": {
        "fine_id": 1,
        "vehicle_id": 1,
        "fine_amount": 150.00,
        "issued_date": "2024-01-01",
        "due_date": "2024-01-15",
        "violation_type": "Speeding",
        "description": "Exceeded speed limit by 15 mph",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Fine retrieved successfully"
}
```

### 5.3 Get Fine List Overdue
**GET** `/get-fine-list-overdue`

**Response Example:**
```json
{
    "success": true,
    "data": [
        {
            "fine_id": 1,
            "vehicle_id": 1,
            "fine_amount": 150.00,
            "issued_date": "2024-01-01",
            "due_date": "2024-01-15",
            "violation_type": "Speeding",
            "description": "Exceeded speed limit by 15 mph",
            "vehicle": {
                "vehicle_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic",
                "owner": {
                    "owner_id": 1,
                    "FName": "John",
                    "LName": "Doe"
                }
            }
        }
    ],
    "message": "Overdue fines retrieved successfully"
}
```

### 5.2 Create Fine
**POST** `/create-fine`

**Request Body:**
```json
{
    "vehicle_id": 1,
    "fine_amount": 200.00,
    "issued_date": "2024-01-20",
    "due_date": "2024-02-20",
    "violation_type": "Parking Violation",
    "description": "Parked in no-parking zone"
}
```

**Validation Rules:**
- `vehicle_id`: Required, must exist in vehicles table
- `fine_amount`: Required, numeric, minimum 0
- `issued_date`: Required, valid date
- `due_date`: Required, must be after issued_date
- `violation_type`: Required, max 100 characters
- `description`: Required, max 500 characters

**Response Example:**
```json
{
    "success": true,
    "data": {
        "fine_id": 201,
        "vehicle_id": 1,
        "fine_amount": 200.00,
        "issued_date": "2024-01-20",
        "due_date": "2024-02-20",
        "violation_type": "Parking Violation",
        "description": "Parked in no-parking zone",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Fine created successfully"
}
```

### 5.5 Update Fine
**PUT** `/update-fine/{fineId}`

**Request Body:** (All fields optional)
```json
{
    "fine_amount": 200.00,
    "due_date": "2024-02-20",
    "description": "Updated violation description"
}
```

**Response Example:**
```json
{
    "success": true,
    "data": {
        "fine_id": 1,
        "vehicle_id": 1,
        "fine_amount": 200.00,
        "issued_date": "2024-01-20",
        "due_date": "2024-02-20",
        "violation_type": "Parking Violation",
        "description": "Updated violation description",
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        }
    },
    "message": "Fine updated successfully"
}
```

### 5.6 Delete Fine
**DELETE** `/delete-fine/{fineId}`

**Response Example:**
```json
{
    "success": true,
    "message": "Fine deleted successfully"
}
```

---

## 6. Advanced Query Operations

### 6.1 Get Vehicle List by Owner
**GET** `/get-vehicle-list-by-owner/{ownerId}`

**Response Example:**
```json
{
    "success": true,
    "data": {
        "owner": {
            "owner_id": 1,
            "FName": "John",
            "LName": "Doe"
        },
        "vehicles": {
            "current_page": 1,
            "data": [
                {
                    "vehicle_id": 1,
                    "owner_id": 1,
                    "vin": "1HGBH41JXMN109186",
                    "make": "Honda",
                    "model": "Civic",
                    "color": "Blue",
                    "year": 2020,
                    "vehicle_status": "Active"
                }
            ],
            "per_page": 15,
            "total": 3
        }
    },
    "message": "Owner vehicles retrieved successfully"
}
```

### 6.2 Get Vehicle History by ID
**GET** `/get-vehicle-history-by-id/{vehicleId}`

**Response Example:**
```json
{
    "success": true,
    "data": {
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        },
        "registrations": [
            {
                "registration_id": 1,
                "registration_date": "2023-01-15",
                "expiration_date": "2024-01-15",
                "registration_number": "REG123456"
            }
        ],
        "insurance": [
            {
                "insurance_id": 1,
                "policy_number": "POL123456",
                "start_date": "2023-01-01",
                "end_date": "2024-01-01",
                "coverage_amount": 50000.00
            }
        ],
        "fines": [
            {
                "fine_id": 1,
                "fine_amount": 150.00,
                "issued_date": "2024-01-01",
                "due_date": "2024-01-15",
                "violation_type": "Speeding"
            }
        ]
    },
    "message": "Vehicle history retrieved successfully"
}
```

### 6.3 Get Vehicle Search by VIN
**GET** `/get-vehicle-search-by-vin?vin=ABC123`

**Query Parameters:**
- `vin`: Required, minimum 3 characters, maximum 50 characters

**Response Example:**
```json
{
    "success": true,
    "data": [
        {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            },
            "registrations": [
                {
                    "registration_id": 1,
                    "registration_number": "REG123456"
                }
            ]
        }
    ],
    "message": "Vehicle search completed successfully"
}
```

### 6.4 Get Owner List with Vehicle Counts
**GET** `/get-owner-list-with-vehicle-counts`

**Query Parameters:**
- `per_page` (optional): Number of items per page (default: 15)

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe",
                "vehicles_count": 3
            },
            {
                "owner_id": 2,
                "FName": "Jane",
                "LName": "Smith",
                "vehicles_count": 2
            }
        ],
        "per_page": 15,
        "total": 250
    },
    "message": "Owners with vehicle counts retrieved successfully"
}
```

### 6.5 Get Vehicle List by Status
**GET** `/get-vehicle-list-by-status/{status}`

**Path Parameters:**
- `status`: Required, must be one of: Active, Inactive, Sold, Stolen

**Response Example:**
```json
{
    "success": true,
    "data": {
        "current_page": 1,
        "data": [
            {
                "vehicle_id": 1,
                "vin": "1HGBH41JXMN109186",
                "make": "Honda",
                "model": "Civic",
                "vehicle_status": "Active",
                "owner": {
                    "owner_id": 1,
                    "FName": "John",
                    "LName": "Doe"
                }
            }
        ],
        "per_page": 15,
        "total": 150
    },
    "message": "Vehicles by status retrieved successfully"
}
```

### 6.6 Get Dashboard Stats Summary
**GET** `/get-dashboard-stats-summary`

**Response Example:**
```json
{
    "success": true,
    "data": {
        "totalVehicles": 200,
        "totalOwners": 250,
        "expiringRegistrations30d": 16,
        "overdueFines": 33,
        "expiringInsurance30d": 14
    },
    "message": "Dashboard stats retrieved successfully"
}
```

### 6.7 Get Vehicle Compliance Score by ID
**GET** `/get-vehicle-compliance-score-by-id/{vehicleId}`

**Response Example:**
```json
{
    "success": true,
    "data": {
        "vehicle": {
            "vehicle_id": 1,
            "vin": "1HGBH41JXMN109186",
            "make": "Honda",
            "model": "Civic",
            "owner": {
                "owner_id": 1,
                "FName": "John",
                "LName": "Doe"
            }
        },
        "score": 80,
        "breakdown": {
            "registration": 40,
            "insurance": 40,
            "fines": 0
        },
        "details": {
            "latestRegistration": {
                "registration_id": 1,
                "expiration_date": "2025-01-15"
            },
            "latestInsurance": {
                "insurance_id": 1,
                "end_date": "2025-01-01"
            },
            "overdueFinesCount": 0
        }
    },
    "message": "Vehicle compliance score retrieved successfully"
}
```

---

## Error Responses

### Validation Error (422)
```json
{
    "success": false,
    "message": "Validation failed",
    "errors": {
        "vin": ["The vin field is required."],
        "year": ["The year must be between 1900 and 2025."]
    }
}
```

### Not Found Error (404)
```json
{
    "success": false,
    "message": "Vehicle not found"
}
```

### Server Error (500)
```json
{
    "success": false,
    "message": "Failed to create vehicle",
    "error": "Database connection failed"
}
```

---

## Security Features

### Input Validation
- All input data is validated using Laravel's validation rules
- SQL injection protection through Eloquent ORM
- XSS protection through proper data sanitization

### Data Integrity
- Foreign key constraints ensure data consistency
- Unique constraints prevent duplicate entries
- Soft deletes preserve data history

### Error Handling
- Comprehensive error handling with appropriate HTTP status codes
- Detailed error messages for debugging
- Graceful handling of database errors

---

## Rate Limiting
Currently not implemented. For production, consider implementing rate limiting using Laravel's built-in throttling middleware.

## CORS
CORS headers are automatically handled by Laravel for API routes.

---

## Testing the API

You can test the API using tools like:
- **Postman**
- **Insomnia**
- **curl**
- **Laravel Tinker**

### Example curl commands:

```bash
# Get vehicles
curl -X GET "http://127.0.0.1:8000/api/v1/get-vehicle-list-with-owners"

# Create vehicle
curl -X POST "http://127.0.0.1:8000/api/v1/create-vehicle" \
  -H "Content-Type: application/json" \
  -d '{
    "owner_id": 1,
    "vin": "1HGBH41JXMN109186",
    "make": "Honda",
    "model": "Civic",
    "color": "Blue",
    "year": 2020,
    "vehicle_status": "Active"
  }'

# Update vehicle
curl -X PUT "http://127.0.0.1:8000/api/v1/update-vehicle/1" \
  -H "Content-Type: application/json" \
  -d '{
    "make": "Toyota",
    "model": "Camry"
  }'

# Delete vehicle
curl -X DELETE "http://127.0.0.1:8000/api/v1/delete-vehicle/1"
```

---

## Complete CRUD Operations Summary

### Vehicle Management (4 endpoints)
- ✅ **CREATE**: `POST /create-vehicle`
- ✅ **READ**: `GET /get-vehicle-list-with-owners`
- ✅ **UPDATE**: `PUT /update-vehicle/{vehicleId}`
- ✅ **DELETE**: `DELETE /delete-vehicle/{vehicleId}`

### Owner Management (5 endpoints)
- ✅ **CREATE**: `POST /create-owner`
- ✅ **READ**: `GET /get-owner-list` + `GET /get-owner-by-id/{ownerId}`
- ✅ **UPDATE**: `PUT /update-owner/{ownerId}`
- ✅ **DELETE**: `DELETE /delete-owner/{ownerId}`

### Registration Management (6 endpoints)
- ✅ **CREATE**: `POST /create-registration`
- ✅ **READ**: `GET /get-registration-list` + `GET /get-registration-by-id/{registrationId}` + `GET /get-registration-list-expiring-soon`
- ✅ **UPDATE**: `PUT /update-registration/{registrationId}`
- ✅ **DELETE**: `DELETE /delete-registration/{registrationId}`

### Insurance Management (6 endpoints)
- ✅ **CREATE**: `POST /create-insurance`
- ✅ **READ**: `GET /get-insurance-list` + `GET /get-insurance-by-id/{insuranceId}` + `GET /get-insurance-list-expiring-soon`
- ✅ **UPDATE**: `PUT /update-insurance/{insuranceId}`
- ✅ **DELETE**: `DELETE /delete-insurance/{insuranceId}`

### Fine Management (6 endpoints)
- ✅ **CREATE**: `POST /create-fine`
- ✅ **READ**: `GET /get-fine-list` + `GET /get-fine-by-id/{fineId}` + `GET /get-fine-list-overdue`
- ✅ **UPDATE**: `PUT /update-fine/{fineId}`
- ✅ **DELETE**: `DELETE /delete-fine/{fineId}`

### Advanced Query Operations (7 endpoints)
- `GET /get-vehicle-list-by-owner/{ownerId}`
- `GET /get-vehicle-history-by-id/{vehicleId}`
- `GET /get-vehicle-search-by-vin`
- `GET /get-owner-list-with-vehicle-counts`
- `GET /get-vehicle-list-by-status/{status}`
- `GET /get-dashboard-stats-summary`
- `GET /get-vehicle-compliance-score-by-id/{vehicleId}`

**Total API Endpoints: 34**
**CRUD Operations: 25**
**Advanced Queries: 7**
**Specialized Lists: 2**