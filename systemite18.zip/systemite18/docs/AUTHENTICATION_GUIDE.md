# Authentication and Security System Guide

## Overview
Laravel application has a comprehensive admin authentication system with role-based access control, action logging, and session management.

## System Components

### 1. Database Tables
- **`admins`** - Stores admin user accounts
- **`admin_roles`** - Defines different admin roles with permission levels
- **`admin_actions`** - Logs all admin actions for audit trails

### 2. Models
- **`Admin`** - Admin user model with role relationship
- **`AdminRole`** - Role model with permission system
- **`AdminAction`** - Action logging model

### 3. Middleware
- **`AuthSession`** - Session-based authentication for admin routes
- **`ApiAuth`** - API key authentication (currently disabled in local environment)

## How to Use the Authentication System

### Step 1: Set Up Initial Data
Run the database seeder to create admin roles and default admin accounts:

```bash
php artisan db:seed --class=AdminSeeder
```

This creates:
- **Super Admin** (role_level: 3) - Full permissions
- **Admin** (role_level: 2) - Most permissions except admin management
- **Operator** (role_level: 1) - Basic data management permissions

Default accounts:
- **superadmin** / admin123
- **admin** / admin123  
- **operator** / admin123

### Step 2: Authentication Endpoints

#### Login
```http
POST /api/v1/admin/login
Content-Type: application/json

{
    "username": "superadmin",
    "password": "admin123"
}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "admin": {
            "admin_id": 1,
            "username": "superadmin",
            "email": "admin@systemite18.com",
            "role": {
                "role_name": "Super Admin",
                "role_level": 3,
                "permissions": {...}
            }
        },
        "token": "random_token_string"
    },
    "message": "Login successful"
}
```

#### Get Profile
```http
GET /api/v1/admin/profile
```

#### Logout
```http
POST /api/v1/admin/logout
```

#### Get Available Roles
```http
GET /api/v1/admin/roles
```

### Step 3: Protected Endpoints

#### Create New Admin (Super Admin Only)
```http
POST /api/v1/admin/create
Content-Type: application/json

{
    "username": "newadmin",
    "email": "newadmin@example.com",
    "password": "securepassword",
    "password_confirmation": "securepassword",
    "role_id": 2
}
```

#### View Admin Actions Log
```http
GET /api/v1/admin/actions?per_page=20
```

### Step 4: Role-Based Access Control

The system has three role levels:

#### Super Admin (Level 3)
- Create/delete other admins
- View all admin actions
- Full access to all vehicle management features
- Can manage the entire system

#### Admin (Level 2)
- View admin actions log
- Full access to vehicle management features
- Cannot create/delete other admins

#### Operator (Level 1)
- Basic vehicle management access
- Cannot view admin actions
- Cannot manage other admins

### Step 5: Protecting Your Vehicle Management Routes

To protect your existing vehicle management endpoints, wrap them with the `auth.session` middleware:

```php
Route::middleware(['auth.session'])->group(function () {
    Route::get('/get-vehicle-list-with-owners', [VehicleSystemController::class, 'getVehicleListWithOwners']);
    Route::post('/create-vehicle', [VehicleSystemController::class, 'createVehicle']);
    // ... other protected routes
});
```

### Step 6: Using Authentication in Controllers

In your controllers, you can access the current admin:

```php
public function someMethod(Request $request)
{
    $currentAdmin = $request->get('current_admin'); // Added by AuthSession middleware
    
    // Log the action
    AdminAction::create([
        'admin_id' => $currentAdmin->admin_id,
        'action_type' => 'vehicle_created',
        'description' => 'Created new vehicle'
    ]);
    
    // Your controller logic...
}
```

### Step 7: Permission Checking

You can check permissions in your controllers:

```php
public function createVehicle(Request $request)
{
    $currentAdmin = $request->get('current_admin');
    $permissions = json_decode($currentAdmin->role->permissions, true);
    
    if (!$permissions['manage_vehicles']) {
        return response()->json([
            'success' => false,
            'message' => 'Insufficient permissions'
        ], 403);
    }
    
    // Create vehicle logic...
}
```

## Security Features

### 1. Password Hashing
All passwords are hashed using Laravel's `Hash` facade.

### 2. Session Management
- Sessions store admin ID and token
- Sessions are validated on each request
- Invalid sessions are automatically cleared

### 3. Action Logging
Every admin action is logged with:
- Admin ID
- Action type
- Description
- Timestamp

### 4. Soft Deletes
Admin accounts are soft deleted, preserving audit trails.

### 5. Role-Based Permissions
JSON-based permission system allows flexible role configuration.

## Production Considerations

### 1. Replace Session Authentication
For production, consider using:
- **Laravel Sanctum** for API token authentication
- **Laravel Passport** for OAuth2 implementation

### 2. API Key Security
Update the `ApiAuth` middleware to use proper API key validation.

### 3. HTTPS
Ensure all authentication endpoints use HTTPS in production.

### 4. Rate Limiting
Add rate limiting to login endpoints to prevent brute force attacks.

### 5. Password Policies
Implement stronger password requirements and password reset functionality.

## Example Usage in Frontend

### JavaScript/React Example
```javascript
// Login
const login = async (username, password) => {
    const response = await fetch('/api/v1/admin/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password })
    });
    
    const data = await response.json();
    if (data.success) {
        // Store token in localStorage or sessionStorage
        localStorage.setItem('admin_token', data.data.token);
        return data.data.admin;
    }
    throw new Error(data.message);
};

// Make authenticated requests
const makeAuthenticatedRequest = async (url, options = {}) => {
    const token = localStorage.getItem('admin_token');
    
    return fetch(url, {
        ...options,
        headers: {
            ...options.headers,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        }
    });
};
```

